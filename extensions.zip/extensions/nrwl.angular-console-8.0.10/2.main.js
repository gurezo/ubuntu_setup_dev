exports.ids = [2];
exports.modules = {

/***/ 100:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "startServer", function() { return startServer; });
/* harmony import */ var _angular_console_server__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(618);
/* harmony import */ var _nestjs_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(579);
/* harmony import */ var _nestjs_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_nestjs_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var vscode__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(0);
/* harmony import */ var vscode__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(vscode__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _get_store_for_context__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1091);
/* harmony import */ var _pseudo_terminal_factory__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2615);






const getPort = __webpack_require__(1051);
async function startServer(context, workspacePath) {
    const port = await getPort({ port: 8888 });
    const store = Object(_get_store_for_context__WEBPACK_IMPORTED_MODULE_4__[/* getStoreForContext */ "a"])(context);
    const selectDirectory = async ({ buttonLabel }) => {
        return await vscode__WEBPACK_IMPORTED_MODULE_3__["window"]
            .showOpenDialog({
            canSelectFolders: true,
            canSelectFiles: false,
            canSelectMany: false,
            openLabel: buttonLabel
        })
            .then(value => {
            if (value && value.length) {
                return value[0].fsPath;
            }
            else {
                return undefined;
            }
        });
    };
    const showNotification = (message, notificationCommands) => {
        vscode__WEBPACK_IMPORTED_MODULE_3__["window"]
            .showInformationMessage(message, ...notificationCommands.map(c => c.label))
            .then(res => {
            const selectedCommand = notificationCommands.find(n => n.label === res);
            if (selectedCommand) {
                if (selectedCommand.action.url) {
                    const opn = __webpack_require__(309);
                    opn(selectedCommand.action.url);
                }
                else {
                    vscode__WEBPACK_IMPORTED_MODULE_3__["commands"].executeCommand(selectedCommand.action.extension, undefined, selectedCommand.action.route);
                }
            }
        });
    };
    const pseudoTerminalFactory = Object(_pseudo_terminal_factory__WEBPACK_IMPORTED_MODULE_5__[/* getPseudoTerminalFactory */ "a"])(context);
    const exports = [
        'serverAddress',
        'store',
        'selectDirectory',
        'pseudoTerminalFactory',
        'assetsPath',
        'showNotification'
    ];
    const assetsPath = path__WEBPACK_IMPORTED_MODULE_2__["join"](context.extensionPath, 'assets', 'public');
    const queryResolver = new _angular_console_server__WEBPACK_IMPORTED_MODULE_0__[/* QueryResolver */ "a"](store);
    if (workspacePath) {
        queryResolver.workspace(workspacePath, {});
    }
    const providers = [
        { provide: _angular_console_server__WEBPACK_IMPORTED_MODULE_0__[/* QueryResolver */ "a"], useValue: queryResolver },
        { provide: 'serverAddress', useValue: `http://localhost:${port}` },
        { provide: 'store', useValue: store },
        { provide: 'selectDirectory', useValue: selectDirectory },
        { provide: 'pseudoTerminalFactory', useValue: pseudoTerminalFactory },
        { provide: 'assetsPath', useValue: assetsPath },
        { provide: 'showNotification', useValue: showNotification }
    ];
    const app = await _nestjs_core__WEBPACK_IMPORTED_MODULE_1__["NestFactory"].create(Object(_angular_console_server__WEBPACK_IMPORTED_MODULE_0__[/* createServerModule */ "b"])(exports, providers), {
        cors: true
    });
    app.useStaticAssets(assetsPath);
    return await app.listen(port, () => { });
}


/***/ }),

/***/ 1088:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return createServerModule; });
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _nestjs_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(125);
/* harmony import */ var _nestjs_common__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_nestjs_common__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _nestjs_graphql__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(173);
/* harmony import */ var _nestjs_graphql__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _resolvers_query_resolver__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(445);
/* harmony import */ var _resolvers_mutation_resolver__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2598);
/* harmony import */ var _resolvers_completion_types_resolver__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2599);
/* harmony import */ var _resolvers_schematic_collection_resolver__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2601);
/* harmony import */ var _resolvers_project_resolver__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2602);
/* harmony import */ var _resolvers_npm_script_resolver__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2603);
/* harmony import */ var _resolvers_docs_resolver__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2604);
/* harmony import */ var _resolvers_workspace_resolver__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2605);
/* harmony import */ var _resolvers_architect_resolver__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(2607);
/* harmony import */ var _nrwl_angular_console_enterprise_electron__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1019);
/* harmony import */ var _nrwl_angular_console_enterprise_electron__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_nrwl_angular_console_enterprise_electron__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _api_read_settings__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(192);
/* harmony import */ var _api_run_command__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(307);
/* harmony import */ var _utils_telemetry__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(617);
/* harmony import */ var _api_docs__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(615);
/* harmony import */ var _utils_file_utils__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(1089);
/* harmony import */ var _nestjs_core__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(579);
/* harmony import */ var _nestjs_core__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(_nestjs_core__WEBPACK_IMPORTED_MODULE_18__);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (undefined && undefined.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};



















function createServerModule(exports, providers) {
    let CoreModule = class CoreModule {
    };
    CoreModule = __decorate([
        Object(_nestjs_common__WEBPACK_IMPORTED_MODULE_1__["Global"])(),
        Object(_nestjs_common__WEBPACK_IMPORTED_MODULE_1__["Module"])({
            providers: [
                ...providers,
                {
                    provide: 'readSettings',
                    useFactory: store => () => Object(_api_read_settings__WEBPACK_IMPORTED_MODULE_13__[/* readSettings */ "a"])(store),
                    inject: ['store']
                },
                { provide: 'commands', useValue: _api_run_command__WEBPACK_IMPORTED_MODULE_14__[/* commands */ "a"] },
                {
                    provide: 'telemetry',
                    useFactory: store => new _utils_telemetry__WEBPACK_IMPORTED_MODULE_15__[/* Telemetry */ "a"](store),
                    inject: ['store']
                },
                { provide: 'docs', useValue: _api_docs__WEBPACK_IMPORTED_MODULE_16__[/* docs */ "a"] }
            ],
            exports: [...exports, 'readSettings', 'commands', 'telemetry', 'docs']
        })
    ], CoreModule);
    let RenderIndex = class RenderIndex {
        constructor(assetsPath) {
            this.assetsPath = assetsPath;
        }
        catch(_exception, host) {
            const ctx = host.switchToHttp();
            const res = ctx.getResponse();
            res.sendFile(path__WEBPACK_IMPORTED_MODULE_0__["join"](this.assetsPath, 'index.html'));
        }
    };
    RenderIndex = __decorate([
        Object(_nestjs_common__WEBPACK_IMPORTED_MODULE_1__["Catch"])(_nestjs_common__WEBPACK_IMPORTED_MODULE_1__["NotFoundException"]),
        __param(0, Object(_nestjs_common__WEBPACK_IMPORTED_MODULE_1__["Inject"])('assetsPath')),
        __metadata("design:paramtypes", [String])
    ], RenderIndex);
    let ServerModule = class ServerModule {
    };
    ServerModule = __decorate([
        Object(_nestjs_common__WEBPACK_IMPORTED_MODULE_1__["Module"])({
            imports: [
                CoreModule,
                _nrwl_angular_console_enterprise_electron__WEBPACK_IMPORTED_MODULE_12__["AngularConsoleExtensionsModule"],
                _nestjs_graphql__WEBPACK_IMPORTED_MODULE_2__["GraphQLModule"].forRoot({
                    typePaths: [
                        path__WEBPACK_IMPORTED_MODULE_0__["join"](__dirname, 'assets/schema.graphql'),
                        path__WEBPACK_IMPORTED_MODULE_0__["join"](__dirname, 'assets/extensions-schema.graphql')
                    ],
                    bodyParserConfig: true
                })
            ],
            providers: [
                _resolvers_query_resolver__WEBPACK_IMPORTED_MODULE_3__[/* QueryResolver */ "a"],
                _resolvers_workspace_resolver__WEBPACK_IMPORTED_MODULE_10__[/* WorkspaceResolver */ "a"],
                _resolvers_schematic_collection_resolver__WEBPACK_IMPORTED_MODULE_6__[/* SchematicCollectionResolver */ "a"],
                _resolvers_architect_resolver__WEBPACK_IMPORTED_MODULE_11__[/* ArchitectResolver */ "a"],
                _resolvers_project_resolver__WEBPACK_IMPORTED_MODULE_7__[/* ProjectResolver */ "a"],
                _resolvers_npm_script_resolver__WEBPACK_IMPORTED_MODULE_8__[/* NpmScriptResolver */ "a"],
                _resolvers_completion_types_resolver__WEBPACK_IMPORTED_MODULE_5__[/* CompletionsTypesResolver */ "a"],
                _resolvers_docs_resolver__WEBPACK_IMPORTED_MODULE_9__[/* DocsResolver */ "a"],
                _resolvers_mutation_resolver__WEBPACK_IMPORTED_MODULE_4__[/* MutationResolver */ "a"],
                _utils_file_utils__WEBPACK_IMPORTED_MODULE_17__[/* FileUtils */ "a"],
                {
                    provide: _nestjs_core__WEBPACK_IMPORTED_MODULE_18__["APP_FILTER"],
                    useClass: RenderIndex
                },
                ...providers
            ],
            controllers: []
        })
    ], ServerModule);
    return ServerModule;
}


/***/ }),

/***/ 1089:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return FileUtils; });
/* harmony import */ var _nestjs_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(125);
/* harmony import */ var _nestjs_common__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_nestjs_common__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var child_process__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(92);
/* harmony import */ var child_process__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(child_process__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(fs__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var os__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(17);
/* harmony import */ var os__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(os__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _api_read_settings__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(192);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (undefined && undefined.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};






let FileUtils = class FileUtils {
    constructor(store) {
        this.store = store;
    }
    isWsl() {
        return !!Object(_api_read_settings__WEBPACK_IMPORTED_MODULE_5__[/* readSettings */ "a"])(this.store).isWsl;
    }
    useNvm() {
        return !!Object(_api_read_settings__WEBPACK_IMPORTED_MODULE_5__[/* readSettings */ "a"])(this.store).useNvm;
    }
    findExecutable(command, cwd) {
        const paths = this.getPaths();
        if (paths === void 0 || paths.length === 0) {
            return this.joinForCommandRun(cwd, command);
        }
        const r = this.findInPath(command, cwd, paths);
        return r ? r : this.joinForCommandRun(cwd, command);
    }
    hasExecutable(command, cwd) {
        const paths = this.getPaths();
        if (paths === void 0 || paths.length === 0) {
            return false;
        }
        else {
            return !!this.findInPath(command, cwd, paths);
        }
    }
    getPaths() {
        if (this.isWsl()) {
            const p = Object(child_process__WEBPACK_IMPORTED_MODULE_1__["execSync"])('wsl -e printenv')
                .toString()
                .split('\n')
                .filter(v => v.startsWith('PATH='))[0]
                .trim();
            return p.substring(5).split(':');
        }
        else {
            return process.env.PATH.split(path__WEBPACK_IMPORTED_MODULE_4__["delimiter"]);
        }
    }
    wslSupportsNvm() {
        if (this.isWsl()) {
            const p = Object(child_process__WEBPACK_IMPORTED_MODULE_1__["execSync"])('wsl -e bash -l -i -c printenv')
                .toString()
                .split('\n')
                .filter(v => v.startsWith('NVM_DIR='))[0]
                .trim();
            return Boolean(p);
        }
        return false;
    }
    convertToWslPath(p) {
        if (this.isWsl() && !p.startsWith('/')) {
            return Object(child_process__WEBPACK_IMPORTED_MODULE_1__["execSync"])(`wsl -e wslpath -u ${p}`)
                .toString()
                .trim();
        }
        else {
            return p;
        }
    }
    unwrapWslPath(p) {
        if (this.isWsl() && p.startsWith('/')) {
            return Object(child_process__WEBPACK_IMPORTED_MODULE_1__["execSync"])(`wsl -e wslpath -w ${p}`)
                .toString()
                .trim();
        }
        else {
            return p;
        }
    }
    findInPath(command, cwd, paths) {
        for (const pathEntry of paths) {
            let fullPath;
            if (path__WEBPACK_IMPORTED_MODULE_4__["isAbsolute"](pathEntry)) {
                fullPath = this.joinForCommandRun(pathEntry, command);
            }
            else {
                fullPath = this.joinForCommandRun(this.convertToWslPath(cwd), pathEntry, command);
            }
            if (Object(fs__WEBPACK_IMPORTED_MODULE_2__["existsSync"])(fullPath + '.exe') &&
                Object(os__WEBPACK_IMPORTED_MODULE_3__["platform"])() === 'win32' &&
                !this.isWsl()) {
                return fullPath + '.exe';
            }
            else if (Object(fs__WEBPACK_IMPORTED_MODULE_2__["existsSync"])(fullPath + '.cmd') &&
                Object(os__WEBPACK_IMPORTED_MODULE_3__["platform"])() === 'win32' &&
                !this.isWsl()) {
                return fullPath + '.cmd';
            }
            else if (Object(fs__WEBPACK_IMPORTED_MODULE_2__["existsSync"])(fullPath)) {
                return fullPath;
            }
        }
        return undefined;
    }
    findClosestNg(d) {
        const dir = this.convertToWslPath(d);
        if (this.directoryExists(this.joinForCommandRun(dir, 'node_modules'))) {
            if (Object(os__WEBPACK_IMPORTED_MODULE_3__["platform"])() === 'win32' && !this.isWsl()) {
                if (this.fileExistsSync(this.joinForCommandRun(dir, 'ng.cmd'))) {
                    return this.joinForCommandRun(dir, 'ng.cmd');
                }
                else {
                    return this.joinForCommandRun(dir, 'node_modules', '.bin', 'ng.cmd');
                }
            }
            else {
                if (this.fileExistsSync(this.joinForCommandRun(dir, 'node_modules', '.bin', 'ng'))) {
                    return this.joinForCommandRun(dir, 'node_modules', '.bin', 'ng');
                }
                else {
                    return this.joinForCommandRun(dir, 'node_modules', '@angular', 'cli', 'bin', 'ng');
                }
            }
        }
        else {
            const parent = path__WEBPACK_IMPORTED_MODULE_4__["dirname"](dir);
            if (parent === dir) {
                throw new Error(`Cannot find 'ng'`);
            }
            return this.findClosestNg(parent);
        }
    }
    joinForCommandRun(...p) {
        return p
            .splice(1)
            .reduce((a, b) => (this.isWsl() ? `${a}/${b}` : path__WEBPACK_IMPORTED_MODULE_4__["join"](a, b)), p[0]);
    }
    directoryExists(filePath) {
        try {
            return Object(fs__WEBPACK_IMPORTED_MODULE_2__["statSync"])(this.unwrapWslPath(filePath)).isDirectory();
        }
        catch (err) {
            return false;
        }
    }
    fileExistsSync(filePath) {
        try {
            return Object(fs__WEBPACK_IMPORTED_MODULE_2__["statSync"])(this.unwrapWslPath(filePath)).isFile();
        }
        catch (err) {
            return false;
        }
    }
};
FileUtils = __decorate([
    Object(_nestjs_common__WEBPACK_IMPORTED_MODULE_0__["Injectable"])(),
    __param(0, Object(_nestjs_common__WEBPACK_IMPORTED_MODULE_0__["Inject"])('store')),
    __metadata("design:paramtypes", [Object])
], FileUtils);



/***/ }),

/***/ 1091:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return getStoreForContext; });
function getStoreForContext(context) {
    return {
        get: (key, defaultValue) => context.globalState.get(key) || defaultValue,
        set: (key, value) => context.globalState.update(key, value),
        delete: (key) => context.globalState.update(key, undefined)
    };
}


/***/ }),

/***/ 1200:
/***/ (function(module, exports) {

function webpackEmptyContext(req) {
	var e = new Error("Cannot find module '" + req + "'");
	e.code = 'MODULE_NOT_FOUND';
	throw e;
}
webpackEmptyContext.keys = function() { return []; };
webpackEmptyContext.resolve = webpackEmptyContext;
module.exports = webpackEmptyContext;
webpackEmptyContext.id = 1200;

/***/ }),

/***/ 1412:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return schematicCollectionsForNgNew; });
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(156);

function schematicCollectionsForNgNew() {
    return [
        {
            name: '@schematics/angular',
            description: 'Default Angular CLI workspace',
            schema: Object(_utils_utils__WEBPACK_IMPORTED_MODULE_0__[/* normalizeSchema */ "m"])(__webpack_require__(1414))
        },
        {
            name: '@nrwl/workspace',
            description: 'Angular CLI power-ups for modern development',
            schema: Object(_utils_utils__WEBPACK_IMPORTED_MODULE_0__[/* normalizeSchema */ "m"])(__webpack_require__(1415))
        }
    ];
}


/***/ }),

/***/ 1416:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return readDependencies; });
function readDependencies(packageJson) {
    const deps = [
        '@angular/cli',
        '@angular/core',
        '@angular/common',
        '@angular/router',
        'typescript',
        'rxjs',
        '@ngrx/store',
        '@ngrx/effects',
        '@nrwl/schematics'
    ];
    return Object.entries({
        ...packageJson.devDependencies,
        ...packageJson.dependencies
    })
        .filter(([name]) => deps.includes(name))
        .map(([name, version]) => ({ name, version }));
}


/***/ }),

/***/ 1417:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* unused harmony export EXTENSTIONS */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return readExtensions; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return availableExtensions; });
const EXTENSTIONS = {
    '@a.grisevich/ng-zorro-antd': 'An enterprise-class UI components based on Ant Design and Angular',
    '@alyle/ui': 'Minimal Design, a set of components for Angular',
    '@angular-buddies/prettier': 'Your buddy who knows how to make your code pretty using Prettier.',
    '@angular-extensions/model': 'Angular Model - Simple state management with minimalistic API, one way data flow, multiple model support and immutable data exposed as RxJS Observable.',
    '@angular-material-extensions/core': 'Set of components, directives and services to boost the app development with angular material 2',
    '@angular-toolkit/serverless': 'Angular Universal PWA boilerplate for serverless environment.',
    '@angular/cdk': 'Angular Material Component Development Kit',
    '@angular/elements': 'Angular - library for using Angular Components as Custom Elements',
    '@angular/fire': 'The official library for Firebase and Angular',
    '@angular/material': 'Angular Material',
    '@angular/pwa': 'PWA schematics for Angular',
    '@augury/schematics': 'Schematics for Augury Labs',
    '@azure/ng-deploy': '@azure/ng-deploy - Deploy Angular apps to Azure using the Angular CLI',
    '@balticcode/ngx-hotkeys': 'An Angular module providing hotkey support.',
    '@briebug/cypress-schematic': 'Add cypress to an Angular CLI project',
    '@briebug/jest': 'Add jest to an Angular CLI project',
    '@briebug/jest-schematic': 'Add jest to an Angular CLI project',
    '@briebug/mat-dialog-schematic': 'A schematic for generating mat dialog components',
    '@briebug/ngrx-entity-schematic': 'An Angular schematic for quickly scaffolding NgRx Entities with actions, effects, reducer, model, service, and passing specs.',
    '@cameltec-ng/schematics': 'A set of schematics for Angular',
    '@capacitor/angular': 'Schematics for capacitor/angular apps.',
    '@clr/angular': 'Angular components for Clarity',
    '@css_christianscharr/ngx-build-plus': 'Extensible Builder for the Angular CLI suitable not only for Angular Elements.',
    '@datorama/akita': 'State Management Tailored-Made for JS Applications',
    '@datorama/akita-experimental': 'State Management Tailored-Made for JS Applications',
    '@davinkevin/jest': 'Angular Schematics which add Jest to your original setup',
    '@devoto13/angular-fontawesome': 'Angular Fontawesome, an Angular library',
    '@dnation/web3': 'A schematics for build decentralised application with Angular and web3',
    '@dx-samples/creative-bootstrap-components': 'Library with reusable WCH components.',
    '@electron-schematics/schematics': 'Schematics specific to Electron',
    '@froko/ng-essentials': 'An essentials schematics for new Angular applications',
    '@gngt/core': 'Gnucoop Angular Toolkit \u003d\u003d\u003d\u003d\u003d\u003d\u003d',
    '@ibm-wch-sdk/wrtp': 'A schematics to enable an application for WRTP',
    '@ionic/angular': 'Angular specific wrappers for @ionic/core',
    '@itrulia/jest-schematic': 'Jest schematics for the @angular/cli',
    '@jarmee/schematics': 'A collection of schematics',
    '@kai1015/serverless': 'Angular Universal PWA boilerplate for serverless environment.',
    '@kamiazya/ngx-speech-recognition': 'Angular 5+ speech recognition service (based on browser implementation such as Chrome).',
    '@kentan-official/schematics': 'Schematics for @kentan-official/core automating creation of sketches',
    '@mace/prettier-schematics': 'Add Prettier to your Angular CLI projects.',
    '@materia/schematics-universal': 'Add Angular Universal support to your angular cli project',
    '@momentum-ui/angular': 'The Cisco Momentum UI Icons library allows developers to easily incorporate Webex Icons and CSS into any application.',
    '@mxth/entity': 'Common utilities for entity reducers',
    '@nativescript/schematics': 'Schematics for NativeScript Angular apps.',
    '@nebular/theme': '@nebular/theme',
    '@netbasal/spectator': 'Angular tests made easy',
    '@ng-bootstrap/schematics': 'ng-bootstrap schematics collection for angular-cli',
    '@ng-toolkit/firebug': 'Add Firebug lite to your Angular project.',
    '@ng-toolkit/pwa': 'Extension for @angular/pwa - adds server-side rendering fixes and update mechanism',
    '@ng-toolkit/serverless': 'Angular Universal PWA boilerplate for serverless environment.',
    '@ng-toolkit/universal': 'Adds Angular Universal support for any Angular CLI project',
    '@ngqp/core': 'Synchronizing form controls with the URL for Angular',
    '@ngrx/data': 'API management for NgRx',
    '@ngrx/effects': 'Side effect model for @ngrx/store',
    '@ngrx/entity': 'Common utilities for entity reducers',
    '@ngrx/router-store': 'Bindings to connect @angular/router to @ngrx/store',
    '@ngrx/schematics': 'NgRx Schematics for Angular',
    '@ngrx/store': 'RxJS powered Redux for Angular apps',
    '@ngrx/store-devtools': 'Developer tools for @ngrx/store',
    '@nguniversal/express-engine': 'Express Engine for running Server Angular Apps',
    '@nguniversal/hapi-engine': 'Hapi Engine for running Server Angular Apps',
    '@ngx-formly/schematics': 'ngx-formly is an Angular 2 module which has a Components to help customize and render JavaScript/JSON configured forms. The formly-form Component and the FormlyConfig service are very powerful and bring unmatched maintainability to your application\u0027s form',
    '@ngx-i18nsupport/tooling': 'Schematics to add the tooling to be used with the Angular 2 i18n workflow',
    '@ngx-kit/core': 'ngx-kit - core module',
    '@ngx-kit/sula': 'Sula — Angular UI components',
    '@ngxs/schematics': 'NGXS schematics for Angular',
    '@notadd/ng-material-pro': 'Angular material2 Extension Components ..',
    '@notadd/ng-material2': 'Angular material2 Extension Components ..',
    '@nrwl/angular': 'Angular Plugin for Nx',
    '@nrwl/cypress': 'Cypress plugin for Nx',
    '@nrwl/express': 'Express Plugin for Nx',
    '@nrwl/jest': 'Jest plugin for Nx',
    '@nrwl/nest': 'Nest Plugin for Nx',
    '@nrwl/node': 'Node Plugin for Nx',
    '@nrwl/react': 'React Plugin for Nx',
    '@nrwl/schematics': 'Angular CLI power-ups for modern Web development: Schematics',
    '@nrwl/web': 'Web Plugin for Nx',
    '@nrwl/workspace': 'Power-ups for Angular CLI',
    '@nstudio/schematics': 'Cross-platform (xplat) tools for Nx workspaces.',
    '@ockilson/local-schematics': 'Setup project specific schematics without bundling npm packages',
    '@ockilson/ng-jest': 'Schematic to setup jest for angular/cli projects',
    '@ockilson/ng-storybook': 'Setup project specific schematics without bundling npm packages',
    '@ockilson/schematics': 'Schematic to run through default setup of angular app (very opinionated)',
    '@oktadev/schematics': 'Schematics for Okta Auth',
    '@pascaliske/schematics': 'Angular schematics collection for integrating setup tools like prettier and storybook.',
    '@paultaku/angular-schematics': 'A blank schematics',
    '@progress/kendo-angular-conversational-ui': 'Kendo UI for Angular Conversational UI components',
    '@progress/kendo-angular-excel-export': 'Kendo UI for Angular Excel Export component',
    '@progress/kendo-angular-menu': 'Kendo UI Angular Menu component',
    '@progress/kendo-angular-pdf-export': 'Kendo UI for Angular PDF Export Component',
    '@progress/kendo-angular-popup': 'Kendo UI Angular 2 Popup component',
    '@progress/kendo-angular-scrollview': 'A ScrollView Component for Angular 2',
    '@progress/kendo-angular-toolbar': 'Kendo UI Angular 2 component starter template',
    '@progress/kendo-angular-upload': 'Kendo UI Angular 2 Upload Component',
    '@progress/kendo-schematics': 'Kendo UI Schematics for Angular',
    '@quramy/angular-lang-service': 'A schematics to add @angular/language-service',
    '@schuchard/prettier': 'An Angular schematic for adding prettier',
    '@slupekdev/vscode': 'Add recommended extensions and configuration to an Angular CLI project',
    '@supine/sofa': 'Angular sofa',
    '@syncfusion/ej2-angular-base': 'A common package of Essential JS 2 base Angular libraries, methods and class definitions',
    '@syncfusion/ej2-angular-buttons': 'A package of feature-rich Essential JS 2 components such as Button, CheckBox, RadioButton and Switch. for Angular',
    '@syncfusion/ej2-angular-calendars': 'A complete package of date or time components with built-in features such as date formatting, inline editing, multiple (range) selection, range restriction, month and year selection, strict mode, and globalization. for Angular',
    '@syncfusion/ej2-angular-charts': 'Feature-rich chart control with built-in support for over 25 chart types, technical indictors, trendline, zooming, tooltip, selection, crosshair and trackball. for Angular',
    '@syncfusion/ej2-angular-circulargauge': 'Essential JS 2 CircularGauge Components for Angular',
    '@syncfusion/ej2-angular-diagrams': 'Feature-rich diagram control to create diagrams like flow charts, organizational charts, mind maps, and BPMN diagrams. Its rich feature set includes built-in shapes, editing, serializing, exporting, printing, overview, data binding, and automatic layouts.',
    '@syncfusion/ej2-angular-documenteditor': 'Feature-rich document editor control with built-in support for context menu, options pane and dialogs. for Angular',
    '@syncfusion/ej2-angular-dropdowns': 'Essential JS 2 DropDown Components for Angular',
    '@syncfusion/ej2-angular-filemanager': 'Essential JS 2 FileManager Component for Angular',
    '@syncfusion/ej2-angular-gantt': 'Essential JS 2 Gantt Component for Angular',
    '@syncfusion/ej2-angular-grids': 'Feature-rich JavaScript datagrid (datatable) control with built-in support for editing, filtering, grouping, paging, sorting, and exporting to Excel. for Angular',
    '@syncfusion/ej2-angular-heatmap': 'Feature rich data visulization control used to visualize the matrix data where the individual values are represented as colors for Angular',
    '@syncfusion/ej2-angular-inplace-editor': 'A package of Essential JS 2 Inplace editor components, which is used to edit and update the value dynamically in server. for Angular',
    '@syncfusion/ej2-angular-inputs': 'A package of Essential JS 2 input components such as Textbox, Color-picker, Masked-textbox, Numeric-textbox, Slider, Upload, and Form-validator that is used to get input from the users. for Angular',
    '@syncfusion/ej2-angular-layouts': 'A package of Essential JS 2 layout pure CSS components such as card and avatar. The card is used as small container to show content in specific structure, whereas the avatars are icons, initials or figures representing particular person. for Angular',
    '@syncfusion/ej2-angular-lineargauge': 'Essential JS 2 LinearGauge Components for Angular',
    '@syncfusion/ej2-angular-lists': 'The listview control allows you to select an item or multiple items from a list-like interface and represents the data in interactive hierarchical structure across different layouts or views. for Angular',
    '@syncfusion/ej2-angular-maps': 'The Maps component is used to visualize the geographical data and represent the statistical data of a particular geographical area on earth with user interactivity, and provides various customizing options for Angular',
    '@syncfusion/ej2-angular-navigations': 'A package of Essential JS 2 navigation components such as Tree-view, Tab, Toolbar, Context-menu, and Accordion which is used to navigate from one page to another for Angular',
    '@syncfusion/ej2-angular-notifications': 'A package of Essential JS 2 notification components such as Toast and Badge which used to notify important information to end-users. for Angular',
    '@syncfusion/ej2-angular-pdfviewer': 'Essential JS 2 PDF viewer Component for Angular',
    '@syncfusion/ej2-angular-pivotview': 'The pivot grid, or pivot table, is used to visualize large sets of relational data in a cross-tabular format, similar to an Excel pivot table. for Angular',
    '@syncfusion/ej2-angular-popups': 'A package of Essential JS 2 popup components such as Dialog and Tooltip that is used to display information or messages in separate pop-ups. for Angular',
    '@syncfusion/ej2-angular-querybuilder': 'Essential JS 2 QueryBuilder for Angular',
    '@syncfusion/ej2-angular-richtexteditor': 'Essential JS 2 RichTextEditor component for Angular',
    '@syncfusion/ej2-angular-schedule': 'Flexible scheduling library with more built-in features and enhanced customization options similar to outlook and google calendar, allowing the users to plan and manage their appointments with efficient data-binding support. for Angular',
    '@syncfusion/ej2-angular-splitbuttons': 'A package of feature-rich Essential JS 2 components such as DropDownButton, SplitButton, ProgressButton and ButtonGroup. for Angular',
    '@syncfusion/ej2-angular-treegrid': 'Essential JS 2 TreeGrid Component for Angular',
    '@syncfusion/ej2-angular-treemap': 'Essential JS 2 TreeMap Components for Angular',
    '@syncfusion/ej2-ng-base': 'A common package of Essential JS 2 base Angular libraries, methods and class definitions',
    '@vendasta/material': 'Angular Material',
    '@willh/hmr': 'Enabling Hot Module Replacement (HMR) feature in your Angular CLI v6 project',
    'angular-fire-schematics': 'AngularFire Schematics',
    'angular-karma-gwt': 'Schematics to update the default karma config file created by the Angluar Cli to integrate jasmine-given and mocha-reporter.',
    'angular-made-with-love': '🚀 An experimental project which demonstrates an Angular Package which contains Angular Elements and Schematics',
    'angular-playground': 'A drop in app module for working on Angular components in isolation (aka Scenario Driven Development).',
    'angular-popper': 'Popover component for Angular 2+ based on Popper.js library.',
    'angular-vscode': 'Useful VSCode plugins for Angular Development',
    'ant-reset-private': 'An enterprise-class UI components based on Ant Design and Angular',
    'apollo-angular': 'Use your GraphQL data in your Angular app, with the Apollo Client',
    'at-ng': '',
    'bootstrap-schematics': 'Bootstrap Options Schema',
    'devblabla-schem-test2': 'DevExtreme schematics are workflow tools you can use in an Angular application created with [DevExtreme CLI](https://github.com/devexpress/DevExtreme-CLI) to add DevExtreme libraries or views and perform other DevExtreme-related tasks. Read [this article]',
    'guozhiqing-momentum': 'Momentum is an Angular Schematic developed by the Bottle Rocket Web Team to build best-in-class web applications faster.',
    'hmr-enabled': 'Enabling Hot Module Replacement (HMR) feature in your Angular CLI v6 project',
    'host-antd': 'An enterprise-class UI components based on Ant Design and Angular',
    'ican-ng-zorro-antd': 'An enterprise-class UI components based on Ant Design and Angular',
    'igniteui-angular': 'Ignite UI for Angular is a dependency-free Angular toolkit for building modern web apps',
    'json-server-schematics': 'Angular schematics for adding json-server to an Angular workspace',
    narik: 'Framework to create angular application',
    'nebular-schematics-test-theme': 'nebular-schematics-test-theme',
    'ng-cli-pug-loader': 'An schematic to add support for .pug files on Angular projects',
    'ng-cosmos-ui': 'An enterprise-class UI components based on Ant Design and Angular',
    'ng-danielszenasi-antd': 'An enterprise-class UI components based on Ant Design and Angular',
    'ng-dockerize': 'Schematic that adds configuration to run angular in docker',
    'ng-lists': 'List Components for Angular',
    'ng-momentum': 'Momentum is an Angular Schematic developed by the Bottle Rocket Web Team to build best-in-class web applications faster.',
    'ng-universal-k8s': 'Angular schematic to add Kubernetes functionality to Angular Universal',
    'ng-z-atsale': 'An enterprise-class UI components based on Ant Design and Angular',
    'ng-zorro-antd': 'An enterprise-class UI components based on Ant Design and Angular',
    'ng-zorro-antd-mobile': 'An enterprise-class mobile UI components based on Ant Design and Angular',
    'ng-zorro-antd-net': 'An enterprise-class UI components based on Ant Design and Angular',
    'ng-zorro-antd-wendzhue-fake': 'An enterprise-class UI components based on Ant Design and Angular',
    'ng-zorro-antd-xinhai': 'An enterprise-class UI components based on Ant Design and Angular',
    'ng-zorro-antd-yj': 'An enterprise-class UI components based on Ant Design and Angular',
    'ngcli-wallaby': 'A schematic to add wallabyJS config to Angular project',
    'ngx-agora': 'Angular 7 wrapper for Agora RTC client (https://www.agora.io/en/)',
    'ngx-animated-gradient': 'Angular Directive that animated the gradient background',
    'ngx-auth-firebaseui': 'Open Source Library for Angular Web Apps to integrate a material user interface for firebase authentication',
    'ngx-bootstrap': 'Native Angular Bootstrap Components',
    'ngx-bootstrap-ci': 'Native Angular Bootstrap Components',
    'ngx-bootstrap-th': 'Native Angular Bootstrap Components',
    'ngx-build-modern': 'Turnkey solution for differential serving in Angular. Serve fewer bytes -\u003e increase performance',
    'ngx-build-plus': "Extends the Angular CLI's build process!",
    'ngx-face-api-js': 'Angular directives for face detection and face recognition in the browser. It is a wrapper for face-api.js, so it is not dependent on the browser implementation.',
    'ngx-onesignal': 'angular 7+ OneSignal Service',
    'ngx-weui': 'WeUI for angular',
    'primeng-schematics': 'Schematics for Prime NG',
    'puppeteer-schematic': 'An Angular Schematic to add Chrome Headless instead of PhantomJS',
    'pz-nz-component': 'An enterprise-class UI components based on Ant Design and Angular',
    'rocky-schematics': 'rocky-schematics collections for angular-cli',
    'shallow-render-schematics': 'Shallow rendering test utility for Angular',
    'testowa-libka': '🚀 An experimental project which demonstrates an Angular Package which contains Angular Elements and Schematics',
    'typewiz-angular': 'An Angular Schematic that automatically adds types to TypeScript code using [TypeWiz](https://www.npmjs.com/package/typewiz-core)',
    'ui-jar-schematics': 'Schematics that add an ui-jar project in an Angular workspace for making documentation',
    'yang-schematics': 'Yet Another Angular Generator'
};
function readExtensions(packageJson) {
    return availableExtensions().filter(e => {
        const hasDep = packageJson.dependencies && packageJson.dependencies[e.name];
        const hasDevDep = packageJson.devDependencies && packageJson.devDependencies[e.name];
        return hasDep || hasDevDep;
    });
}
function availableExtensions() {
    return Object.keys(EXTENSTIONS)
        .sort()
        .map(name => {
        const description = EXTENSTIONS[name];
        return {
            name,
            description
        };
    });
}


/***/ }),

/***/ 1418:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return Commands; });
class Commands {
    constructor(MAX_RECENT, MAX_HISTORY) {
        this.MAX_RECENT = MAX_RECENT;
        this.MAX_HISTORY = MAX_HISTORY;
        this.recent = [];
        this.history = [];
    }
    addCommand(type, id, workspace, command, factory, detailedStatusCalculator, addToRecent = true) {
        const item = {
            id,
            type,
            workspace,
            command,
            status: 'waiting',
            out: '',
            outChunk: '',
            factory,
            detailedStatusCalculator,
            commandRunning: null
        };
        this.insertIntoHistory(item);
        if (addToRecent) {
            this.insertIntoRecent(item);
        }
    }
    restartCommand(id) {
        const c = this.findMatchingCommand(id, this.recent);
        if (c) {
            if (c.status === 'in-progress') {
                this.stopCommands([c]);
            }
            const restarted = {
                ...c,
                status: 'in-progress',
                out: '',
                outChunk: '',
                commandRunning: c.factory()
            };
            this.insertIntoHistory(restarted);
            this.insertIntoRecent(restarted);
            restarted.detailedStatusCalculator.reset();
        }
    }
    stopCommands(commands) {
        commands.forEach(c => {
            if (c.status === 'in-progress') {
                c.status = 'terminated';
                c.detailedStatusCalculator.setStatus('terminated');
                if (c.commandRunning) {
                    c.commandRunning.kill();
                    c.commandRunning = null;
                }
            }
        });
    }
    startCommand(id) {
        const command = this.findMatchingCommand(id, this.history);
        if (command) {
            command.commandRunning = command.factory();
            command.status = 'in-progress';
        }
    }
    addOut(id, out) {
        const c = this.findMatchingCommand(id, this.history);
        if (c) {
            c.out += out;
            c.outChunk += out;
            try {
                c.detailedStatusCalculator.addOut(out);
            }
            catch (e) {
                console.error('detailedStatusCalculator.addOut failed', e.message);
            }
        }
    }
    setFinalStatus(id, status) {
        const c = this.findMatchingCommand(id, this.history);
        if (c && (c.status === 'in-progress' || c.status === 'waiting')) {
            this.setStatus(id, status);
        }
    }
    setStatus(id, status) {
        const c = this.findMatchingCommand(id, this.history);
        if (c) {
            c.status = status;
            try {
                c.detailedStatusCalculator.setStatus(c.status);
            }
            catch (e) {
                console.error('detailedStatusCalculator.setStatus failed', e);
            }
        }
    }
    removeCommand(id) {
        const command = this.findMatchingCommand(id, this.recent);
        if (command) {
            this.stopCommands([command]);
        }
        this.recent = this.withoutCommandWithId(id, this.recent);
    }
    removeAllCommands() {
        const commandInfos = this.recent;
        this.recent = [];
        this.stopCommands(commandInfos);
    }
    findMatchingCommand(id, commands) {
        return [...commands].reverse().find(c => c.id === id);
    }
    insertIntoRecent(c) {
        const sameIdIndex = this.recent.findIndex(r => r.id === c.id);
        if (sameIdIndex > -1) {
            this.recent = [
                ...this.recent.slice(0, sameIdIndex),
                c,
                ...this.recent.slice(sameIdIndex + 1)
            ];
        }
        else if (this.recent.length === this.MAX_RECENT) {
            if (!this.hasCompletedCommands(this.recent)) {
                throw new Error(`Cannot run more than ${this.MAX_RECENT} commands in parallel`);
            }
            this.recent = [...this.withoutFirstCompletedCommand(this.recent), c];
        }
        else {
            this.recent = [...this.recent, c];
        }
    }
    insertIntoHistory(c) {
        const preservedHistory = this.history.length === this.MAX_HISTORY
            ? this.history.slice(1)
            : this.history;
        this.history = [...preservedHistory, c];
    }
    hasCompletedCommands(commands) {
        return !!commands.find(c => this.isCompleted(c));
    }
    withoutFirstCompletedCommand(commands) {
        const index = commands.findIndex(c => this.isCompleted(c));
        return [...commands.slice(0, index), ...commands.slice(index + 1)];
    }
    withoutCommandWithId(id, commands) {
        const index = commands.findIndex(c => c.id === id);
        return [...commands.slice(0, index), ...commands.slice(index + 1)];
    }
    isCompleted(c) {
        return (c.status === 'successful' ||
            c.status === 'failed' ||
            c.status === 'terminated');
    }
}


/***/ }),

/***/ 1419:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* unused harmony export StatusType */
/* unused harmony export BuildDetailedStatusCalculator */
/* unused harmony export TestDetailedStatusCalculator */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return createDetailedStatusCalculator; });
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(156);
/* harmony import */ var _utils_stats__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1420);
/* harmony import */ var _utils_architect__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(705);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(fs__WEBPACK_IMPORTED_MODULE_4__);





var StatusType;
(function (StatusType) {
    StatusType["BUILD"] = "build";
    StatusType["TEST"] = "test";
})(StatusType || (StatusType = {}));
class EmptyDetailedStatusCalculator {
    constructor() {
        this.detailedStatus = null;
    }
    addOut(_) { }
    setStatus(_) { }
    reset() { }
}
class BuildDetailedStatusCalculator {
    constructor(opts) {
        this.processedChunks = {};
        this.isServe = opts.isServe;
        this.isForProduction = opts.isForProduction;
        this.architectOptions = opts.architectOptions;
        this.cwd = opts.cwd;
        this.reset();
    }
    reset() {
        const outputPath = this.architectOptions && this.architectOptions.outputPath
            ? Object(path__WEBPACK_IMPORTED_MODULE_3__["join"])(this.cwd, this.architectOptions.outputPath)
            : undefined;
        const indexFile = this.architectOptions && this.architectOptions.index
            ? Object(path__WEBPACK_IMPORTED_MODULE_3__["join"])(this.cwd, this.architectOptions.index)
            : undefined;
        this.startTime = Date.now();
        this.detailedStatus = {
            outputPath,
            indexFile,
            type: StatusType.BUILD,
            buildStatus: 'build_inprogress',
            progress: 0,
            date: '',
            time: '',
            chunks: [],
            errors: [],
            warnings: [],
            stats: null,
            isForProduction: this.isForProduction
        };
    }
    addOut(value) {
        const _value = value.replace(/[\u001b\u009b][[()#;?]*(?:[0-9]{1,4}(?:;[0-9]{0,4})*)?[0-9A-ORZcf-nqry=><]/g, '');
        const { processedChunks, ...newValue } = BuildDetailedStatusCalculator.updateDetailedStatus({
            ...this.detailedStatus,
            processedChunks: this.processedChunks
        }, _value);
        if (this.processedChunks !== processedChunks && processedChunks) {
            newValue.chunks = Object.values(processedChunks);
            this.processedChunks = processedChunks;
        }
        if (this.isServe) {
            newValue.stats = Object(_utils_stats__WEBPACK_IMPORTED_MODULE_1__[/* calculateStatsFromChunks */ "a"])(newValue.chunks);
        }
        this.detailedStatus = newValue;
    }
    setStatus(value) {
        this.detailedStatus.buildStatus =
            value === 'failed' ? 'build_failure' : 'build_success';
        this.addAssetStats();
        this.addWebpackStats();
    }
    addAssetStats() {
        this.detailedStatus.stats =
            this.architectOptions && this.architectOptions.outputPath
                ? Object(_utils_stats__WEBPACK_IMPORTED_MODULE_1__[/* generateStats */ "b"])(this.architectOptions.outputPath, this.cwd, this.startTime)
                : null;
    }
    addWebpackStats() {
        const statsJsonPath = this.architectOptions && this.architectOptions.outputPath
            ? Object(path__WEBPACK_IMPORTED_MODULE_3__["join"])(this.cwd, this.architectOptions.outputPath, 'stats.json')
            : null;
        if (!statsJsonPath || !Object(fs__WEBPACK_IMPORTED_MODULE_4__["existsSync"])(statsJsonPath)) {
            return;
        }
        try {
            const webpackStats = JSON.parse(Object(fs__WEBPACK_IMPORTED_MODULE_4__["readFileSync"])(statsJsonPath).toString());
            if (Array.isArray(webpackStats.errors)) {
                this.detailedStatus.errors.push(...webpackStats.errors);
            }
            if (Array.isArray(webpackStats.warnings)) {
                this.detailedStatus.warnings.push(...webpackStats.warnings);
            }
        }
        catch (err) {
            this.detailedStatus.errors.push(String(err));
        }
    }
    static updateDetailedStatus(state, value) {
        const serverErrorRegExp = /(Port \d+ is already in use)|(getaddrinfo ENOTFOUND .*)/;
        const newErrors = [];
        let _state = state;
        let processedChunks = _state.processedChunks;
        let date = state.date || '';
        let time = state.time || '';
        let progress = _state.progress;
        let buildStatus = _state.buildStatus;
        const angularServeStarting = value.indexOf('0% compiling') > -1;
        const webpackServeStarting = value.indexOf('｢wdm｣: Compiling...') > -1;
        if (angularServeStarting || webpackServeStarting) {
            progress = 0;
            buildStatus = 'build_inprogress';
            _state = { ..._state, errors: [] };
        }
        else if (value.indexOf('10% building modules') > -1) {
            progress = 10;
            buildStatus = 'build_inprogress';
            _state = { ..._state, errors: [] };
        }
        progress = getNextProgress(progress, value);
        if (value.indexOf('Hash:') > -1) {
            buildStatus =
                buildStatus !== 'build_failure' ? 'build_success' : 'build_failure';
            progress = 100;
            value
                .split(/[\n\r]/)
                .map(v => v.trim())
                .forEach(line => {
                const chunkRegExp = /chunk {(\w+)}\s*([\w|.]+)[^)]*\)\s*([^[]*)\[(\w+)/g;
                const chunkMatch = chunkRegExp.exec(line);
                if (chunkMatch) {
                    processedChunks = {
                        ...processedChunks,
                        [chunkMatch[1]]: {
                            name: chunkMatch[1],
                            file: chunkMatch[2],
                            size: chunkMatch[3].trim(),
                            type: chunkMatch[4]
                        }
                    };
                }
                const dateRegExp = /Date: ([^\s)]+)/g;
                const dateMatch = dateRegExp.exec(line);
                if (dateMatch) {
                    date = dateMatch[1];
                }
                const timeRegExp = /Time: ([^\s)]+)/g;
                const timeMatch = timeRegExp.exec(line);
                if (timeMatch) {
                    time = parseTime(timeMatch[1]);
                }
            });
        }
        if (value.indexOf('ERROR in') > -1) {
            buildStatus = 'build_failure';
            progress = 100;
            newErrors.push(...value
                .substring(value.indexOf('ERROR in') + 8)
                .split(/[\n\r]/)
                .map(v => v.trim())
                .filter(v => v.length > 0));
        }
        const serverErrorMatch = value.match(serverErrorRegExp);
        if (serverErrorMatch) {
            newErrors.push(serverErrorMatch[0]);
        }
        const serverRegExp = /listening on (.+?):(\d+)/;
        const serverMatch = value.match(serverRegExp);
        const errors = newErrors.length > 0 ? _state.errors.concat(newErrors) : _state.errors;
        return {
            ..._state,
            buildStatus,
            processedChunks,
            date,
            time,
            errors,
            progress,
            serverHost: serverMatch ? serverMatch[1] : state.serverHost,
            serverPort: serverMatch ? Number(serverMatch[2]) : state.serverPort
        };
    }
}
class TestDetailedStatusCalculator {
    constructor() {
        this.reset();
    }
    reset() {
        this.lastBuildErrors = [];
        this.detailedStatus = {
            type: StatusType.TEST,
            testStatus: 'test_pending',
            buildProgress: 0,
            total: 0,
            failure: 0,
            success: 0,
            buildErrors: [],
            errors: []
        };
    }
    addOut(rawValue) {
        const value = sanitize(rawValue);
        const buildProgress = getNextProgress(this.detailedStatus.buildProgress, value);
        const { total, failure, success, testStatus, errors, buildErrors, lastBuildErrors } = TestDetailedStatusCalculator.updateDetailedStatus({ ...this.detailedStatus, lastBuildErrors: this.lastBuildErrors }, value);
        this.lastBuildErrors = lastBuildErrors;
        let nextStatus = testStatus;
        if (buildErrors.length > 0) {
            nextStatus = 'build_failure';
        }
        else if (testStatus === 'test_pending' && buildProgress > 0) {
            nextStatus = 'test_building';
        }
        this.detailedStatus = {
            type: StatusType.TEST,
            buildProgress,
            errors,
            buildErrors,
            total,
            failure,
            success,
            testStatus: nextStatus
        };
    }
    static updateDetailedStatus(s, value) {
        let _errors = s.errors;
        let lastBuildErrors = s.lastBuildErrors;
        let buildErrors = s.buildErrors;
        if (TestDetailedStatusCalculator.RUN_BEGIN_REGEXP.test(value)) {
            _errors = [];
            lastBuildErrors = buildErrors;
            buildErrors = [];
        }
        if (TestDetailedStatusCalculator.COMPILE_ERROR_REGEXP.test(value)) {
            buildErrors = lastBuildErrors;
        }
        if (value.indexOf('ERROR in') > -1) {
            buildErrors = buildErrors.concat(value
                .substring(value.indexOf('ERROR in') + 8)
                .split(/[\n\r]/)
                .map(v => v.trim())
                .filter(v => v.length > 0));
        }
        const errors = getNextTestErrorState(_errors, value);
        const match = value.match(TestDetailedStatusCalculator.TEST_PROGRESS_REGEXP);
        if (match) {
            const total = Number(match[2]);
            const soFar = Number(match[1]);
            const failure = Number(match[4] || 0);
            const success = soFar - failure;
            return {
                ...s,
                lastBuildErrors,
                buildErrors,
                errors,
                total: total,
                testStatus: failure + success === total
                    ? failure > 0
                        ? 'test_failure'
                        : 'test_success'
                    : 'test_inprogress',
                failure,
                success
            };
        }
        else {
            return {
                ...s,
                buildErrors,
                lastBuildErrors,
                errors
            };
        }
    }
    setStatus(_) {
        const { failure, success, total } = this.detailedStatus;
        const allRan = total > 0 && failure + success === total;
        this.detailedStatus = {
            ...this.detailedStatus,
            testStatus: !allRan
                ? this.detailedStatus.buildErrors.length > 0
                    ? 'build_failure'
                    : 'test_cancelled'
                : failure > 0
                    ? 'test_failure'
                    : 'test_success'
        };
    }
}
TestDetailedStatusCalculator.TEST_PROGRESS_REGEXP = /[\s\S]*Executed\s+(\d+)\s+of\s+(\d+)\s+(SUCCESS\s+|\((\d+)\s+FAILED\))?[\s\S]*/;
TestDetailedStatusCalculator.RUN_BEGIN_REGEXP = /Executed\s+0\s+of\s+\d+\s+SUCCESS/;
TestDetailedStatusCalculator.COMPILE_ERROR_REGEXP = /Executed\s+0\s+of\s+\d+\s+ERROR/;
const COLOR_OUTPUT_REGEXP = /[\u001b\u009b][[()#;?]*(?:[0-9]{1,4}(?:;[0-9]{0,4})*)?[0-9A-ORZcf-nqry=><]/g;
function sanitize(value) {
    return value.replace(COLOR_OUTPUT_REGEXP, '');
}
const PROGRESS_REGEXP = /\d{1,2}%/g;
function getNextProgress(curr, value) {
    const progressMatch = value.match(PROGRESS_REGEXP);
    if (isFinishedProcessingChunks(value)) {
        return 100;
    }
    else if (progressMatch) {
        const lastBit = progressMatch[progressMatch.length - 1];
        const p = Number(lastBit.substr(0, lastBit.length - 1));
        return Math.max(curr, p);
    }
    else {
        return curr;
    }
}
function isFinishedProcessingChunks(value) {
    return (value.indexOf('Connected on socket') > -1 ||
        (value.indexOf('chunk') > -1 && value.indexOf('Hash:') > -1));
}
const NEW_CASE_REGEXP = /^\s*[^()]+\([^)]+\)+(.+) FAILED\s*$/;
const ERROR_REGEXP = /^\s+((Error:.+)|(Expected .+))$/;
const TRACE_REGEXP = /^\s+( {2}at .+)$/;
function getNextTestErrorState(_buffer, value) {
    let buffer = _buffer;
    if (value.indexOf('Connected on socket') > -1) {
        buffer = [];
    }
    const lines = value.split(/[\r\n]/);
    lines.forEach((line, idx) => {
        let match;
        if ((match = line.match(NEW_CASE_REGEXP))) {
            const label = match[1].trim();
            if (buffer.every(b => b.label !== label)) {
                buffer = [...buffer, { label, details: '' }];
            }
        }
        else if ((match = line.match(ERROR_REGEXP))) {
            const [last, ...rest] = buffer.reverse();
            const additionalErrors = collectPreviousErrorsFrom(idx - 1, lines);
            if (last) {
                const newLine = `${additionalErrors.join('')}${match[1]}`;
                buffer = [
                    ...rest,
                    { ...last, details: newLine ? `${last.details}${newLine}\n` : '' }
                ];
            }
        }
        else if ((match = line.match(TRACE_REGEXP))) {
            const [last, ...rest] = buffer.reverse();
            if (last) {
                buffer = [
                    ...rest,
                    { ...last, details: `${last.details}${match[1]}\n` }
                ];
            }
        }
    });
    return buffer;
}
function collectPreviousErrorsFrom(idx, lines) {
    const xs = [];
    let i = idx;
    while (i > 0) {
        const curr = lines[i];
        if (curr.indexOf('FAILED') > -1 || TRACE_REGEXP.test(curr)) {
            break;
        }
        else if (curr) {
            xs.unshift(curr.replace(/\t/g, ''), '\n');
        }
        i--;
    }
    return xs;
}
function parseTime(s) {
    if (s.endsWith('ms')) {
        const x = Number(s.slice(0, s.length - 2));
        if (Number.isInteger(x)) {
            return `${(x / 1000).toFixed(2)}s`;
        }
    }
    return s;
}
function createDetailedStatusCalculator(cwd, cmds) {
    const operationName = cmds[0];
    const project = cmds[1];
    const { json: angularJson } = Object(_utils_utils__WEBPACK_IMPORTED_MODULE_0__[/* readJsonFile */ "n"])('./angular.json', cwd);
    const architect = Object(_utils_architect__WEBPACK_IMPORTED_MODULE_2__[/* getProjectArchitect */ "d"])(project, operationName, angularJson);
    const builder = architect.builder;
    if (_utils_architect__WEBPACK_IMPORTED_MODULE_2__[/* SUPPORTED_KARMA_TEST_BUILDERS */ "b"].includes(builder)) {
        return new TestDetailedStatusCalculator();
    }
    if (_utils_architect__WEBPACK_IMPORTED_MODULE_2__[/* SUPPORTED_BUILD_BUILDERS */ "a"].includes(builder)) {
        const isForProduction = cmds.includes('--configuration=production');
        const options = architect.options;
        return new BuildDetailedStatusCalculator({
            isServe: false,
            isForProduction,
            architectOptions: options,
            cwd
        });
    }
    if (_utils_architect__WEBPACK_IMPORTED_MODULE_2__[/* SUPPORTED_SERVE_BUILDERS */ "c"].includes(builder)) {
        const isForProduction = cmds.includes('--configuration=production');
        const options = architect.options;
        return new BuildDetailedStatusCalculator({
            isServe: true,
            isForProduction,
            architectOptions: options,
            cwd
        });
    }
    return new EmptyDetailedStatusCalculator();
}


/***/ }),

/***/ 1420:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return generateStats; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return calculateStatsFromChunks; });
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(fs__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var shelljs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(706);
/* harmony import */ var shelljs__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(shelljs__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var zlib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(91);
/* harmony import */ var zlib__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(zlib__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _stats_constants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1429);
/* harmony import */ var source_map_explorer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1430);
/* harmony import */ var source_map_explorer__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(source_map_explorer__WEBPACK_IMPORTED_MODULE_5__);






class FileSystemFileSizeGetter {
    read(asset, cwd) {
        const filePath = cwd ? Object(path__WEBPACK_IMPORTED_MODULE_1__["join"])(cwd, '/', asset) : asset;
        const file = Object(fs__WEBPACK_IMPORTED_MODULE_0__["readFileSync"])(filePath);
        return {
            parsed: file.length,
            gzipped: Object(zlib__WEBPACK_IMPORTED_MODULE_3__["gzipSync"])(file).length
        };
    }
}
class FileNameNormalizer {
    constructor(cwd) {
        this.cwdPrefixRegexp = new RegExp(`^[\/]*(${cwd.toLowerCase().replace(/^\//, '')})?[\/]*(.*)`);
    }
    normalize(s) {
        const match = this.cwdPrefixRegexp.exec(s.toLowerCase());
        const file = match ? match[2] : s.toLowerCase();
        for (const k of Object.keys(_stats_constants__WEBPACK_IMPORTED_MODULE_4__[/* SPECIAL_SOURCE_FILE_MAPPINGS */ "a"])) {
            if (file.startsWith(k)) {
                return file.replace(k, _stats_constants__WEBPACK_IMPORTED_MODULE_4__[/* SPECIAL_SOURCE_FILE_MAPPINGS */ "a"][k]);
            }
        }
        return file;
    }
}
function generateStats(_outputPath, cwd, earliestTimeStamp) {
    const outputPath = Object(path__WEBPACK_IMPORTED_MODULE_1__["join"])(cwd, _outputPath);
    const fileSizeGetter = new FileSystemFileSizeGetter();
    const modulesByBundle = {};
    const summary = {
        assets: createSizeData(),
        modules: 0,
        dependencies: 0
    };
    const outputAssets = getAssets(outputPath, earliestTimeStamp);
    const assets = [];
    const bundles = [];
    const normalizedCwd = cwd.replace(/\\/g, '/');
    const fileNormalizer = new FileNameNormalizer(normalizedCwd);
    outputAssets.forEach((asset) => {
        const sizes = fileSizeGetter.read(asset, outputPath);
        const modules = [];
        summary.assets.parsed += sizes.parsed;
        summary.assets.gzipped += sizes.gzipped;
        assets.push({ file: asset, sizes });
        if (asset.endsWith('.js')) {
            bundles.push({ file: asset, sizes });
            try {
                const sourceMapData = source_map_explorer__WEBPACK_IMPORTED_MODULE_5__(Object(path__WEBPACK_IMPORTED_MODULE_1__["join"])(outputPath, asset));
                Object.keys(sourceMapData.files).forEach(_file => {
                    const size = sourceMapData.files[_file];
                    summary.modules += size;
                    if (_file === '<unmapped>') {
                        modules.push({
                            size,
                            file: _file,
                            isDep: false
                        });
                    }
                    else {
                        const file = fileNormalizer.normalize(_file);
                        const isDep = /node_modules/.test(file);
                        if (isDep) {
                            summary.dependencies += size;
                        }
                        modules.push({
                            size,
                            file,
                            isDep
                        });
                    }
                });
            }
            catch (e) {
                summary.modules += sizes.parsed;
                modules.push({
                    size: sizes.parsed,
                    file: asset,
                    isDep: false
                });
            }
        }
        modulesByBundle[asset] = modules;
    });
    return {
        assets,
        bundles,
        modulesByBundle,
        summary
    };
}
function calculateStatsFromChunks(cs) {
    const assets = [];
    const summary = {
        assets: createSizeData(),
        modules: 0,
        dependencies: 0
    };
    const bundles = [];
    cs.forEach((c, idx) => {
        const chunkData = {
            id: String(idx),
            file: c.file,
            sizes: createSizeData()
        };
        const size = parseSizeFromBuildOutput(c.size);
        chunkData.sizes.parsed = size;
        summary.assets.parsed += size;
        summary.modules += size;
        bundles.push(chunkData);
        assets.push({
            file: c.file,
            sizes: chunkData.sizes
        });
    });
    return {
        assets,
        bundles,
        modulesByBundle: {},
        summary
    };
}
function createSizeData() {
    return { gzipped: 0, parsed: 0 };
}
const EXCLUDED_FILES_REGEXP = /^(stats\.json|.*\.map)$/;
function getAssets(p, earliestTimeStamp) {
    const files = Object(shelljs__WEBPACK_IMPORTED_MODULE_2__["ls"])('-lR', p).filter((f) => {
        if (!f.isFile() || EXCLUDED_FILES_REGEXP.test(f.name)) {
            return false;
        }
        return true;
    });
    return files
        .filter((f) => f.mtimeMs >= earliestTimeStamp)
        .map((f) => f.name);
}
function parseSizeFromBuildOutput(s) {
    const matched = s.match(/([\d.]+)\s*(kb|b|mb)/i);
    if (matched) {
        const x = Number(matched[1]);
        switch (matched[2]) {
            case 'b':
                return x;
            case 'kb':
                return x * 1000;
            case 'mb':
                return x * 1000 * 1000;
            case 'gb':
                return x * 1000 * 1000 * 1000;
            default:
                return 0;
        }
    }
    else {
        return 0;
    }
}


/***/ }),

/***/ 1428:
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./cat": 711,
	"./cat.js": 711,
	"./cd": 478,
	"./cd.js": 478,
	"./chmod": 712,
	"./chmod.js": 712,
	"./common": 124,
	"./common.js": 124,
	"./cp": 479,
	"./cp.js": 479,
	"./dirs": 713,
	"./dirs.js": 713,
	"./echo": 714,
	"./echo.js": 714,
	"./error": 480,
	"./error.js": 480,
	"./exec": 715,
	"./exec-child": 716,
	"./exec-child.js": 716,
	"./exec.js": 715,
	"./find": 717,
	"./find.js": 717,
	"./grep": 718,
	"./grep.js": 718,
	"./head": 719,
	"./head.js": 719,
	"./ln": 720,
	"./ln.js": 720,
	"./ls": 483,
	"./ls.js": 483,
	"./mkdir": 721,
	"./mkdir.js": 721,
	"./mv": 722,
	"./mv.js": 722,
	"./popd": 723,
	"./popd.js": 723,
	"./pushd": 724,
	"./pushd.js": 724,
	"./pwd": 482,
	"./pwd.js": 482,
	"./rm": 484,
	"./rm.js": 484,
	"./sed": 725,
	"./sed.js": 725,
	"./set": 726,
	"./set.js": 726,
	"./sort": 727,
	"./sort.js": 727,
	"./tail": 728,
	"./tail.js": 728,
	"./tempdir": 481,
	"./tempdir.js": 481,
	"./test": 729,
	"./test.js": 729,
	"./to": 730,
	"./to.js": 730,
	"./toEnd": 731,
	"./toEnd.js": 731,
	"./touch": 732,
	"./touch.js": 732,
	"./uniq": 733,
	"./uniq.js": 733,
	"./which": 734,
	"./which.js": 734
};


function webpackContext(req) {
	var id = webpackContextResolve(req);
	return __webpack_require__(id);
}
function webpackContextResolve(req) {
	var id = map[req];
	if(!(id + 1)) { // check for number or string
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	}
	return id;
}
webpackContext.keys = function webpackContextKeys() {
	return Object.keys(map);
};
webpackContext.resolve = webpackContextResolve;
module.exports = webpackContext;
webpackContext.id = 1428;

/***/ }),

/***/ 1429:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return SPECIAL_SOURCE_FILE_MAPPINGS; });
const SPECIAL_SOURCE_FILE_MAPPINGS = {
    'packages/animations': 'node_modules/@angular/animations',
    'packages/cdk': 'node_modules/@angular/cdk',
    'packages/cli': 'node_modules/@angular/cli',
    'packages/compiler': 'node_modules/@angular/compiler',
    'packages/compiler-cli': 'node_modules/@angular/compiler-cli',
    'packages/common': 'node_modules/@angular/common',
    'packages/core': 'node_modules/@angular/core',
    'packages/elements': 'node_modules/@angular/elements',
    'packages/flex-layout': 'node_modules/@angular/flex-layout',
    'packages/forms': 'node_modules/@angular/forms',
    'packages/http': 'node_modules/@angular/http',
    'packages/language-service': 'node_modules/@angular/language-service',
    'packages/material': 'node_modules/@angular/material',
    'packages/platform-server': 'node_modules/@angular/platform-server',
    'packages/platform-browser': 'node_modules/@angular/platform-browser',
    'packages/platform-browser-dynamic': 'node_modules/@angular/platform-browser-dynamic',
    'packages/router': 'node_modules/@angular/router',
    'src/animations': 'node_modules/@angular/animations',
    'src/cdk': 'node_modules/@angular/cdk',
    'src/cli': 'node_modules/@angular/cli',
    'src/compiler': 'node_modules/@angular/compiler',
    'src/compiler-cli': 'node_modules/@angular/compiler-cli',
    'src/common': 'node_modules/@angular/common',
    'src/core': 'node_modules/@angular/core',
    'src/elements': 'node_modules/@angular/elements',
    'src/flex-layout': 'node_modules/@angular/flex-layout',
    'src/forms': 'node_modules/@angular/forms',
    'src/http': 'node_modules/@angular/http',
    'src/language-service': 'node_modules/@angular/language-service',
    'src/material': 'node_modules/@angular/material',
    'src/platform-server': 'node_modules/@angular/platform-server',
    'src/platform-browser': 'node_modules/@angular/platform-browser',
    'src/platform-browser-dynamic': 'node_modules/@angular/platform-browser-dynamic',
    'src/router': 'node_modules/@angular/router',
    'modules/effects': 'node_modules/@ngrx/effects',
    'modules/entity': 'node_modules/@ngrx/entity',
    'modules/router-store': 'node_modules/@ngrx/router-store',
    'modules/schematics': 'node_modules/@ngrx/schematics',
    'modules/store': 'node_modules/@ngrx/store',
    'modules/store-devtools': 'node_modules/@ngrx/store-devtools',
    buildin: 'node_modules/webpack/buildin',
    'modules/@nrwl': 'node_modules/@nrwl',
    'src/lib/nx': 'node_modules/@nrwl/nx',
    'src/lib/tabs': 'node_modules/@angular/material/tabs',
    'src/lib/tree': 'node_modules/@angular/material/tree',
    'src/lib/tooltip': 'node_modules/@angular/material/tooltip',
    'src/lib/sidenav': 'node_modules/@angular/material/sidenav',
    'src/lib/radio': 'node_modules/@angular/material/radio',
    'src/lib/card': 'node_modules/@angular/material/card',
    'src/lib/core': 'node_modules/@angular/material/core',
    'src/lib/autocomplete': 'node_modules/@angular/material/autocomplete',
    'src/lib/sort': 'node_modules/@angular/material/sort',
    'src/lib/chips': 'node_modules/@angular/material/chips',
    'src/lib/input': 'node_modules/@angular/material/input',
    'src/lib/progress-bar': 'node_modules/@angular/material/progress-bar',
    'src/lib/slide-toggle': 'node_modules/@angular/material/slide-toggle',
    'src/lib/datepicker': 'node_modules/@angular/material/datepicker',
    'src/lib/typings': 'node_modules/@angular/material/typings',
    'src/lib/toolbar': 'node_modules/@angular/material/toolbar',
    'src/lib/checkbox': 'node_modules/@angular/material/checkbox',
    'src/lib/slider': 'node_modules/@angular/material/slider',
    'src/lib/stepper': 'node_modules/@angular/material/stepper',
    'src/lib/progress-spinner': 'node_modules/@angular/material/progress-spinner',
    'src/lib/esm2015': 'node_modules/@angular/material/esm2015',
    'src/lib/esm5': 'node_modules/@angular/material/esm5',
    'src/lib/dialog': 'node_modules/@angular/material/dialog',
    'src/lib/form-field': 'node_modules/@angular/material/form-field',
    'src/lib/expansion': 'node_modules/@angular/material/expansion',
    'src/lib/button': 'node_modules/@angular/material/button',
    'src/lib/table': 'node_modules/@angular/material/table',
    'src/lib/list': 'node_modules/@angular/material/list',
    'src/lib/divider': 'node_modules/@angular/material/divider',
    'src/lib/menu': 'node_modules/@angular/material/menu',
    'src/lib/bottom-sheet': 'node_modules/@angular/material/bottom-sheet',
    'src/lib/select': 'node_modules/@angular/material/select',
    'src/lib/icon': 'node_modules/@angular/material/icon',
    'src/lib/paginator': 'node_modules/@angular/material/paginator',
    'src/lib/schematics': 'node_modules/@angular/material/schematics',
    'src/lib/prebuilt-themes': 'node_modules/@angular/material/prebuilt-themes',
    'src/lib/bundles': 'node_modules/@angular/material/bundles',
    'src/lib/badge': 'node_modules/@angular/material/badge',
    'src/lib/snack-bar': 'node_modules/@angular/material/snack-bar',
    'src/lib/grid-list': 'node_modules/@angular/material/grid-list',
    'src/lib/flex': 'node_modules/@angular/flex-layout/flex',
    'src/lib/extended': 'node_modules/@angular/flex-layout/extended',
    'src/lib/grid': 'node_modules/@angular/flex-layout/grid'
};


/***/ }),

/***/ 1499:
/***/ (function(module, exports) {

function webpackEmptyContext(req) {
	var e = new Error("Cannot find module '" + req + "'");
	e.code = 'MODULE_NOT_FOUND';
	throw e;
}
webpackEmptyContext.keys = function() { return []; };
webpackEmptyContext.resolve = webpackEmptyContext;
module.exports = webpackEmptyContext;
webpackEmptyContext.id = 1499;

/***/ }),

/***/ 156:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "e", function() { return files; });
/* unused harmony export fileContents */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return exists; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "g", function() { return findExecutable; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "i", function() { return hasExecutable; });
/* unused harmony export findClosestNg */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "k", function() { return listOfUnnestedNpmPackages; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "j", function() { return listFiles; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return directoryExists; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return fileExistsSync; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "n", function() { return readJsonFile; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "m", function() { return normalizeSchema; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "h", function() { return getPrimitiveValue; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "f", function() { return filterByName; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "l", function() { return normalizePath; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return cacheFiles; });
/* harmony import */ var child_process__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(92);
/* harmony import */ var child_process__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(child_process__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(fs__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var os__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(17);
/* harmony import */ var os__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(os__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_3__);




const stripJsonComments = __webpack_require__(1413);
const files = {};
let fileContents = {};
function exists(cmd) {
    try {
        if (Object(os__WEBPACK_IMPORTED_MODULE_2__["platform"])() === 'win32') {
            Object(child_process__WEBPACK_IMPORTED_MODULE_0__["execSync"])(`where ${cmd}`).toString();
        }
        else {
            Object(child_process__WEBPACK_IMPORTED_MODULE_0__["execSync"])(`which ${cmd}`).toString();
        }
        return true;
    }
    catch (error) {
        return false;
    }
}
function findExecutable(command, cwd) {
    const paths = process.env.PATH.split(path__WEBPACK_IMPORTED_MODULE_3__["delimiter"]);
    if (paths === void 0 || paths.length === 0) {
        return path__WEBPACK_IMPORTED_MODULE_3__["join"](cwd, command);
    }
    const r = findInPath(command, cwd, paths);
    return r ? r : path__WEBPACK_IMPORTED_MODULE_3__["join"](cwd, command);
}
function hasExecutable(command, cwd) {
    const paths = process.env.PATH.split(path__WEBPACK_IMPORTED_MODULE_3__["delimiter"]);
    if (paths === void 0 || paths.length === 0) {
        return false;
    }
    else {
        return !!findInPath(command, cwd, paths);
    }
}
function findInPath(command, cwd, paths) {
    for (const pathEntry of paths) {
        let fullPath;
        if (path__WEBPACK_IMPORTED_MODULE_3__["isAbsolute"](pathEntry)) {
            fullPath = path__WEBPACK_IMPORTED_MODULE_3__["join"](pathEntry, command);
        }
        else {
            fullPath = path__WEBPACK_IMPORTED_MODULE_3__["join"](cwd, pathEntry, command);
        }
        if (Object(fs__WEBPACK_IMPORTED_MODULE_1__["existsSync"])(fullPath + '.exe')) {
            return fullPath + '.exe';
        }
        else if (Object(fs__WEBPACK_IMPORTED_MODULE_1__["existsSync"])(fullPath + '.cmd')) {
            return fullPath + '.cmd';
        }
        else if (Object(fs__WEBPACK_IMPORTED_MODULE_1__["existsSync"])(fullPath)) {
            return fullPath;
        }
    }
    return undefined;
}
function findClosestNg(dir) {
    if (directoryExists(path__WEBPACK_IMPORTED_MODULE_3__["join"](dir, 'node_modules'))) {
        if (Object(os__WEBPACK_IMPORTED_MODULE_2__["platform"])() === 'win32') {
            if (fileExistsSync(path__WEBPACK_IMPORTED_MODULE_3__["join"](dir, 'ng.cmd'))) {
                return path__WEBPACK_IMPORTED_MODULE_3__["join"](dir, 'ng.cmd');
            }
            else {
                return path__WEBPACK_IMPORTED_MODULE_3__["join"](dir, 'node_modules', '.bin', 'ng.cmd');
            }
        }
        else {
            if (fileExistsSync(path__WEBPACK_IMPORTED_MODULE_3__["join"](dir, 'node_modules', '.bin', 'ng'))) {
                return path__WEBPACK_IMPORTED_MODULE_3__["join"](dir, 'node_modules', '.bin', 'ng');
            }
            else {
                return path__WEBPACK_IMPORTED_MODULE_3__["join"](dir, 'node_modules', '@angular', 'cli', 'bin', 'ng');
            }
        }
    }
    else {
        return findClosestNg(path__WEBPACK_IMPORTED_MODULE_3__["dirname"](dir));
    }
}
function listOfUnnestedNpmPackages(nodeModulesDir) {
    const res = [];
    Object(fs__WEBPACK_IMPORTED_MODULE_1__["readdirSync"])(nodeModulesDir).forEach(npmPackageOrScope => {
        if (npmPackageOrScope.startsWith('@')) {
            Object(fs__WEBPACK_IMPORTED_MODULE_1__["readdirSync"])(path__WEBPACK_IMPORTED_MODULE_3__["join"](nodeModulesDir, npmPackageOrScope)).forEach(p => {
                res.push(`${npmPackageOrScope}/${p}`);
            });
        }
        else {
            res.push(npmPackageOrScope);
        }
    });
    return res;
}
function listFiles(dirName) {
    if (dirName.indexOf('node_modules') > -1)
        return [];
    if (dirName.indexOf('dist') > -1)
        return [];
    const res = [dirName];
    try {
        Object(fs__WEBPACK_IMPORTED_MODULE_1__["readdirSync"])(dirName).forEach(c => {
            const child = path__WEBPACK_IMPORTED_MODULE_3__["join"](dirName, c);
            try {
                if (!Object(fs__WEBPACK_IMPORTED_MODULE_1__["statSync"])(child).isDirectory()) {
                    res.push(child);
                }
                else if (Object(fs__WEBPACK_IMPORTED_MODULE_1__["statSync"])(child).isDirectory()) {
                    res.push(...listFiles(child));
                }
            }
            catch (e) { }
        });
    }
    catch (e) { }
    return res;
}
function cacheJsonFiles(basedir) {
    try {
        const nodeModulesDir = path__WEBPACK_IMPORTED_MODULE_3__["join"](basedir, 'node_modules');
        const packages = listOfUnnestedNpmPackages(nodeModulesDir);
        const res = {};
        packages.forEach(p => {
            const filePath = path__WEBPACK_IMPORTED_MODULE_3__["join"](nodeModulesDir, p, 'package.json');
            if (!fileExistsSync(filePath))
                return;
            res[filePath] = readAndParseJson(path__WEBPACK_IMPORTED_MODULE_3__["join"](nodeModulesDir, p, 'package.json'));
        });
        return res;
    }
    catch (e) {
        return {};
    }
}
function directoryExists(filePath) {
    try {
        return Object(fs__WEBPACK_IMPORTED_MODULE_1__["statSync"])(filePath).isDirectory();
    }
    catch (err) {
        return false;
    }
}
function fileExistsSync(filePath) {
    try {
        return Object(fs__WEBPACK_IMPORTED_MODULE_1__["statSync"])(filePath).isFile();
    }
    catch (err) {
        return false;
    }
}
function readAndParseJson(fullFilePath) {
    return JSON.parse(stripJsonComments(Object(fs__WEBPACK_IMPORTED_MODULE_1__["readFileSync"])(fullFilePath).toString()));
}
function readJsonFile(filePath, basedir) {
    const fullFilePath = path__WEBPACK_IMPORTED_MODULE_3__["join"](basedir, filePath);
    const cache = basedir.endsWith('node_modules');
    if (cache && fileContents[fullFilePath]) {
        return {
            path: fullFilePath,
            json: fileContents[fullFilePath]
        };
    }
    else if (Object(fs__WEBPACK_IMPORTED_MODULE_1__["existsSync"])(fullFilePath)) {
        return {
            path: fullFilePath,
            json: readAndParseJson(fullFilePath)
        };
    }
    else {
        return {
            path: fullFilePath,
            json: {}
        };
    }
}
function normalizeSchema(p, projectDefaults) {
    try {
        const res = [];
        Object.entries(p.properties).forEach(([k, v]) => {
            if (v.visible === undefined || v.visible) {
                const d = getDefault(v);
                const r = (p.required && p.required.indexOf(k) > -1) || hasSource(v);
                const workspaceDefault = projectDefaults && projectDefaults[k];
                res.push({
                    name: k,
                    type: String(v.type || 'string'),
                    description: v.description || '',
                    defaultValue: workspaceDefault === undefined ? d : workspaceDefault,
                    required: Boolean(r),
                    positional: Boolean(isPositional(v)),
                    enum: v.enum
                });
            }
        });
        return res;
    }
    catch (e) {
        console.error(`normalizeSchema error: '${e.message}'`);
        throw e;
    }
}
function getPrimitiveValue(value) {
    if (typeof value === 'string' ||
        typeof value === 'number' ||
        typeof value === 'boolean' ||
        value === null) {
        return value.toString();
    }
    else {
        return undefined;
    }
}
function getDefault(prop) {
    if (prop.default === undefined && prop.$default === undefined) {
        return undefined;
    }
    const d = prop.default !== undefined ? prop.default : prop.$default;
    return !d.$source ? d.toString() : undefined;
}
function isPositional(prop) {
    if (prop.default === undefined && prop.$default === undefined) {
        return false;
    }
    const d = prop.default !== undefined ? prop.default : prop.$default;
    return d.$source === 'argv';
}
function hasSource(prop) {
    if (prop.default === undefined && prop.$default === undefined) {
        return false;
    }
    const d = prop.default !== undefined ? prop.default : prop.$default;
    return !!d.$source;
}
function filterByName(t, args) {
    return args.name ? t.filter((s) => s.name === args.name) : t;
}
function normalizePath(value) {
    const firstPart = value.split('/')[0];
    if (!firstPart)
        return value;
    if (!firstPart.endsWith(':'))
        return value;
    return value
        .replace(new RegExp('/', 'g'), '\\')
        .split('\\')
        .filter(r => !!r)
        .join('\\');
}
function cacheFiles(p) {
    setTimeout(() => {
        files[p] = listFiles(p);
        fileContents = cacheJsonFiles(p);
        setTimeout(() => {
            cacheFiles(p);
        }, 60000);
    }, 0);
}


/***/ }),

/***/ 192:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return readSettings; });
/* unused harmony export settingsChange$ */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return storeSettings; });
/* harmony import */ var _nrwl_angular_console_enterprise_electron__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1019);
/* harmony import */ var _nrwl_angular_console_enterprise_electron__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_nrwl_angular_console_enterprise_electron__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var os__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(17);
/* harmony import */ var os__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(os__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(232);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(rxjs__WEBPACK_IMPORTED_MODULE_2__);



function readSettings(store) {
    const settings = store.get('settings') || {};
    settings.isWindows = Object(os__WEBPACK_IMPORTED_MODULE_1__["platform"])() === 'win32';
    if (settings.canCollectData === undefined) {
        settings.canCollectData = store.get('canCollectData', false);
    }
    if (settings.recent === undefined) {
        settings.recent = [];
    }
    settings.recent.forEach(t => {
        if (t.pinnedProjectNames === undefined) {
            t.pinnedProjectNames = [];
        }
    });
    if (settings.installNodeManually === undefined) {
        settings.installNodeManually = false;
    }
    if (settings.enableDetailedStatus === undefined) {
        settings.enableDetailedStatus = true;
    }
    if (settings.channel === undefined) {
        settings.channel = 'latest';
    }
    if (settings.workspaceSchematicsDirectory === undefined) {
        settings.workspaceSchematicsDirectory = 'tools/schematics';
    }
    if (settings.workspaceSchematicsNpmScript === undefined) {
        settings.workspaceSchematicsNpmScript = 'workspace-schematic';
    }
    if (settings.isWsl === undefined || Object(os__WEBPACK_IMPORTED_MODULE_1__["platform"])() !== 'win32') {
        settings.isWsl = false;
    }
    if (settings.useNvm === undefined) {
        settings.useNvm = false;
    }
    try {
        settings.isConnectUser = !!_nrwl_angular_console_enterprise_electron__WEBPACK_IMPORTED_MODULE_0__["authUtils"].getIdTokenFromStore();
    }
    catch {
        settings.isConnectUser = false;
    }
    return settings;
}
const storeSettingsSubject = new rxjs__WEBPACK_IMPORTED_MODULE_2__["Subject"]();
const settingsChange$ = storeSettingsSubject.asObservable();
function storeSettings(store, value) {
    store.set('settings', value);
    storeSettingsSubject.next(value);
}


/***/ }),

/***/ 2037:
/***/ (function(module, exports) {

function webpackEmptyContext(req) {
	var e = new Error("Cannot find module '" + req + "'");
	e.code = 'MODULE_NOT_FOUND';
	throw e;
}
webpackEmptyContext.keys = function() { return []; };
webpackEmptyContext.resolve = webpackEmptyContext;
module.exports = webpackEmptyContext;
webpackEmptyContext.id = 2037;

/***/ }),

/***/ 209:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _lib_generated_graphql_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(700);
/* harmony import */ var _lib_generated_graphql_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_lib_generated_graphql_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (checked) */ if(__webpack_require__.o(_lib_generated_graphql_types__WEBPACK_IMPORTED_MODULE_0__, "Architect")) __webpack_require__.d(__webpack_exports__, "Architect", function() { return _lib_generated_graphql_types__WEBPACK_IMPORTED_MODULE_0__["Architect"]; });

/* harmony reexport (checked) */ if(__webpack_require__.o(_lib_generated_graphql_types__WEBPACK_IMPORTED_MODULE_0__, "IsNodeInstalledResult")) __webpack_require__.d(__webpack_exports__, "IsNodeInstalledResult", function() { return _lib_generated_graphql_types__WEBPACK_IMPORTED_MODULE_0__["IsNodeInstalledResult"]; });

/* harmony reexport (checked) */ if(__webpack_require__.o(_lib_generated_graphql_types__WEBPACK_IMPORTED_MODULE_0__, "NpmScript")) __webpack_require__.d(__webpack_exports__, "NpmScript", function() { return _lib_generated_graphql_types__WEBPACK_IMPORTED_MODULE_0__["NpmScript"]; });

/* harmony reexport (checked) */ if(__webpack_require__.o(_lib_generated_graphql_types__WEBPACK_IMPORTED_MODULE_0__, "Project")) __webpack_require__.d(__webpack_exports__, "Project", function() { return _lib_generated_graphql_types__WEBPACK_IMPORTED_MODULE_0__["Project"]; });

/* harmony reexport (checked) */ if(__webpack_require__.o(_lib_generated_graphql_types__WEBPACK_IMPORTED_MODULE_0__, "SchematicCollection")) __webpack_require__.d(__webpack_exports__, "SchematicCollection", function() { return _lib_generated_graphql_types__WEBPACK_IMPORTED_MODULE_0__["SchematicCollection"]; });

/* harmony reexport (checked) */ if(__webpack_require__.o(_lib_generated_graphql_types__WEBPACK_IMPORTED_MODULE_0__, "Settings")) __webpack_require__.d(__webpack_exports__, "Settings", function() { return _lib_generated_graphql_types__WEBPACK_IMPORTED_MODULE_0__["Settings"]; });

/* harmony reexport (checked) */ if(__webpack_require__.o(_lib_generated_graphql_types__WEBPACK_IMPORTED_MODULE_0__, "Workspace")) __webpack_require__.d(__webpack_exports__, "Workspace", function() { return _lib_generated_graphql_types__WEBPACK_IMPORTED_MODULE_0__["Workspace"]; });




/***/ }),

/***/ 2334:
/***/ (function(module, exports) {

function webpackEmptyContext(req) {
	var e = new Error("Cannot find module '" + req + "'");
	e.code = 'MODULE_NOT_FOUND';
	throw e;
}
webpackEmptyContext.keys = function() { return []; };
webpackEmptyContext.resolve = webpackEmptyContext;
module.exports = webpackEmptyContext;
webpackEmptyContext.id = 2334;

/***/ }),

/***/ 2374:
/***/ (function(module, exports) {

function webpackEmptyContext(req) {
	var e = new Error("Cannot find module '" + req + "'");
	e.code = 'MODULE_NOT_FOUND';
	throw e;
}
webpackEmptyContext.keys = function() { return []; };
webpackEmptyContext.resolve = webpackEmptyContext;
module.exports = webpackEmptyContext;
webpackEmptyContext.id = 2374;

/***/ }),

/***/ 2526:
/***/ (function(module, exports) {

function webpackEmptyContext(req) {
	var e = new Error("Cannot find module '" + req + "'");
	e.code = 'MODULE_NOT_FOUND';
	throw e;
}
webpackEmptyContext.keys = function() { return []; };
webpackEmptyContext.resolve = webpackEmptyContext;
module.exports = webpackEmptyContext;
webpackEmptyContext.id = 2526;

/***/ }),

/***/ 2598:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return MutationResolver; });
/* harmony import */ var _nestjs_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(125);
/* harmony import */ var _nestjs_common__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_nestjs_common__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _nestjs_graphql__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(173);
/* harmony import */ var _nestjs_graphql__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var os__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(17);
/* harmony import */ var os__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(os__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _api_docs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(615);
/* harmony import */ var _api_read_editors__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(704);
/* harmony import */ var _api_read_recent_actions__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(702);
/* harmony import */ var _api_read_settings__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(192);
/* harmony import */ var _api_run_command__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(307);
/* harmony import */ var _types__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(616);
/* harmony import */ var _types__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_types__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _utils_file_utils__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1089);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (undefined && undefined.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a, _b, _c;











let MutationResolver = class MutationResolver {
    constructor(store, pseudoTerminalFactory, selectDirectoryImpl, fileUtils) {
        this.store = store;
        this.pseudoTerminalFactory = pseudoTerminalFactory;
        this.selectDirectoryImpl = selectDirectoryImpl;
        this.fileUtils = fileUtils;
    }
    async ngAdd(p, name) {
        try {
            return Object(_api_run_command__WEBPACK_IMPORTED_MODULE_8__[/* runCommand */ "b"])('add', p, 'ng', this.fileUtils.findClosestNg(p), ['add', name, '--no-interactive'], this.pseudoTerminalFactory, this.fileUtils);
        }
        catch (e) {
            console.error(e);
            throw new Error(`Error when running 'ng add'. Message: "${e.message}"`);
        }
    }
    async ngNew(p, name, collection, newCommand) {
        try {
            return Object(_api_run_command__WEBPACK_IMPORTED_MODULE_8__[/* runCommand */ "b"])('new', p, 'new-workspace', path__WEBPACK_IMPORTED_MODULE_3__["join"](__dirname, 'assets', Object(os__WEBPACK_IMPORTED_MODULE_2__["platform"])() === 'win32' && !this.fileUtils.isWsl()
                ? 'new-workspace.cmd'
                : 'new-workspace'), [
                name,
                `--directory=${name}`,
                `--collection=${collection}`,
                ...newCommand,
                '--no-interactive'
            ], this.pseudoTerminalFactory, this.fileUtils);
        }
        catch (e) {
            console.error(e);
            throw new Error(`Error when running 'ng new'. Message: "${e.message}"`);
        }
    }
    async generate(p, dr, genCommand) {
        try {
            const dryRun = dr ? ['--dry-run'] : [];
            return Object(_api_run_command__WEBPACK_IMPORTED_MODULE_8__[/* runCommand */ "b"])('generate', p, 'ng', this.fileUtils.findClosestNg(p), ['generate', ...genCommand, ...dryRun, '--no-interactive'], this.pseudoTerminalFactory, this.fileUtils, !dr);
        }
        catch (e) {
            console.error(e);
            throw new Error(`Error when running 'ng generate'. Message: "${e.message}"`);
        }
    }
    async generateUsingNpm(p, npmClient, dr, genCommand) {
        try {
            const dryRun = dr ? ['--dry-run'] : [];
            return Object(_api_run_command__WEBPACK_IMPORTED_MODULE_8__[/* runCommand */ "b"])('npm', p, npmClient, this.fileUtils.findExecutable(npmClient, p), [...genCommand, ...dryRun, '--no-interactive'], this.pseudoTerminalFactory, this.fileUtils, !dr);
        }
        catch (e) {
            console.error(e);
            throw new Error(`Error when running npm script. Message: "${e.message}"`);
        }
    }
    async runNg(p, rc) {
        try {
            return Object(_api_run_command__WEBPACK_IMPORTED_MODULE_8__[/* runCommand */ "b"])('ng', p, 'ng', this.fileUtils.findClosestNg(p), rc, this.pseudoTerminalFactory, this.fileUtils);
        }
        catch (e) {
            console.error(e);
            throw new Error(`Error when running 'ng ...'. Message: "${e.message}"`);
        }
    }
    async runNpm(p, rc, npmClient) {
        try {
            return Object(_api_run_command__WEBPACK_IMPORTED_MODULE_8__[/* runCommand */ "b"])('npm', p, npmClient, this.fileUtils.findExecutable(npmClient, p), rc, this.pseudoTerminalFactory, this.fileUtils);
        }
        catch (e) {
            console.error(e);
            throw new Error(`Error when running npm script. Message:"${e.message}"`);
        }
    }
    async stopCommand(id) {
        try {
            const c = _api_run_command__WEBPACK_IMPORTED_MODULE_8__[/* commands */ "a"].findMatchingCommand(id, _api_run_command__WEBPACK_IMPORTED_MODULE_8__[/* commands */ "a"].recent);
            if (c) {
                _api_run_command__WEBPACK_IMPORTED_MODULE_8__[/* commands */ "a"].stopCommands([c]);
                return { result: true };
            }
            else {
                return { result: false };
            }
        }
        catch (e) {
            console.error(e);
            throw new Error(`Error when stopping commands. Message: "${e.message}"`);
        }
    }
    async openInBrowser(url) {
        if (url) {
            const opn = __webpack_require__(309);
            opn(url);
            return { result: true };
        }
        else {
            return { result: false };
        }
    }
    async showItemInFolder(item) {
        if (item) {
            const opn = __webpack_require__(309);
            opn(item).catch((err) => console.error(err));
            return { result: true };
        }
        else {
            return { result: false };
        }
    }
    async removeCommand(id) {
        try {
            _api_run_command__WEBPACK_IMPORTED_MODULE_8__[/* commands */ "a"].removeCommand(id);
            return { result: true };
        }
        catch (e) {
            console.error(e);
            throw new Error(`Error when removing commands. Message: "${e.message}"`);
        }
    }
    async removeAllCommands() {
        try {
            _api_run_command__WEBPACK_IMPORTED_MODULE_8__[/* commands */ "a"].removeAllCommands();
            return { result: true };
        }
        catch (e) {
            console.error(e);
            throw new Error(`Error when removing commands. Message: "${e.message}"`);
        }
    }
    async restartCommand(id) {
        try {
            _api_run_command__WEBPACK_IMPORTED_MODULE_8__[/* commands */ "a"].restartCommand(id);
            return { result: true };
        }
        catch (e) {
            console.error(e);
            throw new Error(`Error when restarting commands. Message: "${e.message}"`);
        }
    }
    openInEditor(editor, p) {
        try {
            Object(_api_read_editors__WEBPACK_IMPORTED_MODULE_5__[/* openInEditor */ "b"])(editor, p);
            return { response: 'successful' };
        }
        catch (e) {
            console.error(e);
            throw new Error(`Error when opening an editor. Message: "${e.message}"`);
        }
    }
    async selectDirectory(dialogButtonLabel, dialogTitle) {
        if (process.env.CI === 'true') {
            return {
                selectedDirectoryPath: '/tmp'
            };
        }
        else {
            const directoryPath = await this.selectDirectoryImpl({
                buttonLabel: dialogButtonLabel,
                title: dialogTitle
            });
            return {
                selectedDirectoryPath: directoryPath || null
            };
        }
    }
    updateSettings(data) {
        Object(_api_read_settings__WEBPACK_IMPORTED_MODULE_7__[/* storeSettings */ "b"])(this.store, JSON.parse(data));
        return Object(_api_read_settings__WEBPACK_IMPORTED_MODULE_7__[/* readSettings */ "a"])(this.store);
    }
    saveRecentAction(workspacePath, projectName, actionName, schematicName) {
        const key = `${workspacePath}/${projectName}`;
        Object(_api_read_recent_actions__WEBPACK_IMPORTED_MODULE_6__[/* storeTriggeredAction */ "b"])(this.store, key, actionName, schematicName);
        return Object(_api_read_recent_actions__WEBPACK_IMPORTED_MODULE_6__[/* readRecentActions */ "a"])(this.store, key);
    }
    async openDoc(id) {
        const result = await _api_docs__WEBPACK_IMPORTED_MODULE_4__[/* docs */ "a"].openDoc(id).toPromise();
        return { result };
    }
};
__decorate([
    Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_1__["Mutation"])(),
    __param(0, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_1__["Args"])('path')), __param(1, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_1__["Args"])('name')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], MutationResolver.prototype, "ngAdd", null);
__decorate([
    Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_1__["Mutation"])(),
    __param(0, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_1__["Args"])('path')),
    __param(1, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_1__["Args"])('name')),
    __param(2, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_1__["Args"])('collection')),
    __param(3, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_1__["Args"])('newCommand')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, Array]),
    __metadata("design:returntype", Promise)
], MutationResolver.prototype, "ngNew", null);
__decorate([
    Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_1__["Mutation"])(),
    __param(0, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_1__["Args"])('path')),
    __param(1, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_1__["Args"])('dryRun')),
    __param(2, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_1__["Args"])('genCommand')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Boolean, Array]),
    __metadata("design:returntype", Promise)
], MutationResolver.prototype, "generate", null);
__decorate([
    Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_1__["Mutation"])(),
    __param(0, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_1__["Args"])('path')),
    __param(1, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_1__["Args"])('npmClient')),
    __param(2, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_1__["Args"])('dryRun')),
    __param(3, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_1__["Args"])('genCommand')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Boolean, Array]),
    __metadata("design:returntype", Promise)
], MutationResolver.prototype, "generateUsingNpm", null);
__decorate([
    Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_1__["Mutation"])(),
    __param(0, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_1__["Args"])('path')), __param(1, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_1__["Args"])('runCommand')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Array]),
    __metadata("design:returntype", Promise)
], MutationResolver.prototype, "runNg", null);
__decorate([
    Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_1__["Mutation"])(),
    __param(0, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_1__["Args"])('path')),
    __param(1, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_1__["Args"])('runCommand')),
    __param(2, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_1__["Args"])('npmClient')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Array, String]),
    __metadata("design:returntype", Promise)
], MutationResolver.prototype, "runNpm", null);
__decorate([
    Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_1__["Mutation"])(),
    __param(0, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_1__["Args"])('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], MutationResolver.prototype, "stopCommand", null);
__decorate([
    Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_1__["Mutation"])(),
    __param(0, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_1__["Args"])('url')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], MutationResolver.prototype, "openInBrowser", null);
__decorate([
    Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_1__["Mutation"])(),
    __param(0, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_1__["Args"])('item')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], MutationResolver.prototype, "showItemInFolder", null);
__decorate([
    Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_1__["Mutation"])(),
    __param(0, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_1__["Args"])('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], MutationResolver.prototype, "removeCommand", null);
__decorate([
    Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_1__["Mutation"])(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], MutationResolver.prototype, "removeAllCommands", null);
__decorate([
    Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_1__["Mutation"])(),
    __param(0, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_1__["Args"])('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], MutationResolver.prototype, "restartCommand", null);
__decorate([
    Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_1__["Mutation"])(),
    __param(0, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_1__["Args"])('editor')), __param(1, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_1__["Args"])('path')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_a = typeof _api_read_editors__WEBPACK_IMPORTED_MODULE_5__["Editor"] !== "undefined" && _api_read_editors__WEBPACK_IMPORTED_MODULE_5__["Editor"]) === "function" ? _a : Object, String]),
    __metadata("design:returntype", void 0)
], MutationResolver.prototype, "openInEditor", null);
__decorate([
    Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_1__["Mutation"])(),
    __param(0, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_1__["Args"])('dialogButtonLabel')),
    __param(1, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_1__["Args"])('dialogTitle')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], MutationResolver.prototype, "selectDirectory", null);
__decorate([
    Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_1__["Mutation"])(),
    __param(0, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_1__["Args"])('data')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], MutationResolver.prototype, "updateSettings", null);
__decorate([
    Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_1__["Mutation"])(),
    __param(0, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_1__["Args"])('workspacePath')),
    __param(1, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_1__["Args"])('projectName')),
    __param(2, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_1__["Args"])('actionName')),
    __param(3, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_1__["Args"])('schematicName')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String]),
    __metadata("design:returntype", void 0)
], MutationResolver.prototype, "saveRecentAction", null);
__decorate([
    Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_1__["Mutation"])(),
    __param(0, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_1__["Args"])('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], MutationResolver.prototype, "openDoc", null);
MutationResolver = __decorate([
    Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_1__["Resolver"])(),
    __param(0, Object(_nestjs_common__WEBPACK_IMPORTED_MODULE_0__["Inject"])('store')),
    __param(1, Object(_nestjs_common__WEBPACK_IMPORTED_MODULE_0__["Inject"])('pseudoTerminalFactory')),
    __param(2, Object(_nestjs_common__WEBPACK_IMPORTED_MODULE_0__["Inject"])('selectDirectory')),
    __metadata("design:paramtypes", [Object, Object, typeof (_b = typeof _types__WEBPACK_IMPORTED_MODULE_9__["SelectDirectory"] !== "undefined" && _types__WEBPACK_IMPORTED_MODULE_9__["SelectDirectory"]) === "function" ? _b : Object, typeof (_c = typeof _utils_file_utils__WEBPACK_IMPORTED_MODULE_10__[/* FileUtils */ "a"] !== "undefined" && _utils_file_utils__WEBPACK_IMPORTED_MODULE_10__[/* FileUtils */ "a"]) === "function" ? _c : Object])
], MutationResolver);



/***/ }),

/***/ 2599:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CompletionsTypesResolver; });
/* harmony import */ var _angular_console_schema__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(209);
/* harmony import */ var _api_completions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2600);
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(156);
/* harmony import */ var _nestjs_graphql__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(173);
/* harmony import */ var _nestjs_graphql__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_3__);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (undefined && undefined.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a, _b, _c, _d;




let CompletionsTypesResolver = class CompletionsTypesResolver {
    files(workspace, input) {
        return Object(_api_completions__WEBPACK_IMPORTED_MODULE_1__[/* completeFiles */ "b"])(_utils_utils__WEBPACK_IMPORTED_MODULE_2__[/* files */ "e"], workspace, input);
    }
    projects(workspace, input) {
        return Object(_api_completions__WEBPACK_IMPORTED_MODULE_1__[/* completeProjects */ "d"])(workspace, input);
    }
    localModules(workspace, input) {
        return Object(_api_completions__WEBPACK_IMPORTED_MODULE_1__[/* completeLocalModules */ "c"])(_utils_utils__WEBPACK_IMPORTED_MODULE_2__[/* files */ "e"], workspace, input);
    }
    absoluteModules(workspace, input) {
        return Object(_api_completions__WEBPACK_IMPORTED_MODULE_1__[/* completeAbsoluteModules */ "a"])(_utils_utils__WEBPACK_IMPORTED_MODULE_2__[/* files */ "e"], workspace, input);
    }
};
__decorate([
    Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_3__["ResolveProperty"])(),
    __param(0, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_3__["Parent"])()), __param(1, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_3__["Args"])('input')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_a = typeof _angular_console_schema__WEBPACK_IMPORTED_MODULE_0__["Workspace"] !== "undefined" && _angular_console_schema__WEBPACK_IMPORTED_MODULE_0__["Workspace"]) === "function" ? _a : Object, String]),
    __metadata("design:returntype", void 0)
], CompletionsTypesResolver.prototype, "files", null);
__decorate([
    Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_3__["ResolveProperty"])(),
    __param(0, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_3__["Parent"])()), __param(1, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_3__["Args"])('input')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_b = typeof _angular_console_schema__WEBPACK_IMPORTED_MODULE_0__["Workspace"] !== "undefined" && _angular_console_schema__WEBPACK_IMPORTED_MODULE_0__["Workspace"]) === "function" ? _b : Object, String]),
    __metadata("design:returntype", void 0)
], CompletionsTypesResolver.prototype, "projects", null);
__decorate([
    Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_3__["ResolveProperty"])(),
    __param(0, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_3__["Parent"])()), __param(1, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_3__["Args"])('input')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_c = typeof _angular_console_schema__WEBPACK_IMPORTED_MODULE_0__["Workspace"] !== "undefined" && _angular_console_schema__WEBPACK_IMPORTED_MODULE_0__["Workspace"]) === "function" ? _c : Object, String]),
    __metadata("design:returntype", void 0)
], CompletionsTypesResolver.prototype, "localModules", null);
__decorate([
    Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_3__["ResolveProperty"])(),
    __param(0, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_3__["Parent"])()),
    __param(1, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_3__["Args"])('input')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_d = typeof _angular_console_schema__WEBPACK_IMPORTED_MODULE_0__["Workspace"] !== "undefined" && _angular_console_schema__WEBPACK_IMPORTED_MODULE_0__["Workspace"]) === "function" ? _d : Object, String]),
    __metadata("design:returntype", void 0)
], CompletionsTypesResolver.prototype, "absoluteModules", null);
CompletionsTypesResolver = __decorate([
    Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_3__["Resolver"])('CompletionsTypes')
], CompletionsTypesResolver);



/***/ }),

/***/ 2600:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return completeFiles; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return completeProjects; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return completeLocalModules; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return completeAbsoluteModules; });
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(156);


function completeFiles(files, workspace, input) {
    const p = workspace.path;
    if (!files[p])
        return [];
    return files[p]
        .filter(f => f.indexOf(input) > -1)
        .map(value => value.substring(p.length + 1))
        .map(value => ({ value }));
}
function completeProjects(workspace, input) {
    return workspace.projects
        .map((p) => p.name)
        .filter((p) => p.indexOf(input) > -1)
        .map((value) => ({ value }));
}
function completeLocalModules(files, workspace, input) {
    const p = workspace.path;
    if (!files[p])
        return [];
    return files[p]
        .filter(f => f.indexOf('module.ts') > -1)
        .filter(f => f.indexOf(input) > -1)
        .map(fullPath => {
        const modulePath = fullPath.substring(Object(_utils_utils__WEBPACK_IMPORTED_MODULE_1__[/* normalizePath */ "l"])(workspace.path).length + 1);
        let value;
        if (modulePath.indexOf(path__WEBPACK_IMPORTED_MODULE_0__["join"]('src', 'app')) > -1) {
            value = modulePath.substring(modulePath.indexOf(path__WEBPACK_IMPORTED_MODULE_0__["join"]('src', 'app')) + 8);
        }
        else {
            value = modulePath.substring(modulePath.indexOf(path__WEBPACK_IMPORTED_MODULE_0__["join"]('src', 'lib')) + 8);
        }
        return {
            value,
            display: modulePath
        };
    });
}
function completeAbsoluteModules(files, workspace, input) {
    const p = workspace.path;
    if (!files[p])
        return [];
    return files[p]
        .filter(f => f.indexOf('module.ts') > -1)
        .filter(f => f.indexOf(input) > -1)
        .map(fullPath => {
        const modulePath = fullPath.substring(Object(_utils_utils__WEBPACK_IMPORTED_MODULE_1__[/* normalizePath */ "l"])(workspace.path).length + 1);
        return {
            value: modulePath,
            display: modulePath
        };
    });
}


/***/ }),

/***/ 2601:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return SchematicCollectionResolver; });
/* harmony import */ var _angular_console_schema__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(209);
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(156);
/* harmony import */ var _nestjs_graphql__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(173);
/* harmony import */ var _nestjs_graphql__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_2__);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (undefined && undefined.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a;



let SchematicCollectionResolver = class SchematicCollectionResolver {
    schematics(parent, name) {
        return Object(_utils_utils__WEBPACK_IMPORTED_MODULE_1__[/* filterByName */ "f"])(parent.schematics, { name });
    }
};
__decorate([
    Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_2__["ResolveProperty"])(),
    __param(0, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_2__["Parent"])()),
    __param(1, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_2__["Args"])('name')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_a = typeof _angular_console_schema__WEBPACK_IMPORTED_MODULE_0__["SchematicCollection"] !== "undefined" && _angular_console_schema__WEBPACK_IMPORTED_MODULE_0__["SchematicCollection"]) === "function" ? _a : Object, String]),
    __metadata("design:returntype", void 0)
], SchematicCollectionResolver.prototype, "schematics", null);
SchematicCollectionResolver = __decorate([
    Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_2__["Resolver"])('SchematicCollection')
], SchematicCollectionResolver);



/***/ }),

/***/ 2602:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ProjectResolver; });
/* harmony import */ var _angular_console_schema__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(209);
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(156);
/* harmony import */ var _nestjs_graphql__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(173);
/* harmony import */ var _nestjs_graphql__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_2__);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (undefined && undefined.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a;



let ProjectResolver = class ProjectResolver {
    architect(parent, name) {
        return Object(_utils_utils__WEBPACK_IMPORTED_MODULE_1__[/* filterByName */ "f"])(parent.architect, { name });
    }
};
__decorate([
    Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_2__["ResolveProperty"])(),
    __param(0, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_2__["Parent"])()), __param(1, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_2__["Args"])('name')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_a = typeof _angular_console_schema__WEBPACK_IMPORTED_MODULE_0__["Project"] !== "undefined" && _angular_console_schema__WEBPACK_IMPORTED_MODULE_0__["Project"]) === "function" ? _a : Object, String]),
    __metadata("design:returntype", void 0)
], ProjectResolver.prototype, "architect", null);
ProjectResolver = __decorate([
    Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_2__["Resolver"])('Project')
], ProjectResolver);



/***/ }),

/***/ 2603:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return NpmScriptResolver; });
/* harmony import */ var _angular_console_schema__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(209);
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(156);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _api_read_npm_scripts__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(703);
/* harmony import */ var _nestjs_graphql__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(173);
/* harmony import */ var _nestjs_graphql__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_4__);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (undefined && undefined.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a;





let NpmScriptResolver = class NpmScriptResolver {
    schema(parent, context) {
        if (!Object(_utils_utils__WEBPACK_IMPORTED_MODULE_1__[/* directoryExists */ "b"])(path__WEBPACK_IMPORTED_MODULE_2__["join"](context.path, 'node_modules'))) {
            throw new Error(`node_modules is not found`);
        }
        return Object(_api_read_npm_scripts__WEBPACK_IMPORTED_MODULE_3__[/* readNpmScriptSchema */ "a"])(context.path, parent.name);
    }
};
__decorate([
    Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_4__["ResolveProperty"])(),
    __param(0, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_4__["Parent"])()), __param(1, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_4__["Context"])()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_a = typeof _angular_console_schema__WEBPACK_IMPORTED_MODULE_0__["NpmScript"] !== "undefined" && _angular_console_schema__WEBPACK_IMPORTED_MODULE_0__["NpmScript"]) === "function" ? _a : Object, Object]),
    __metadata("design:returntype", void 0)
], NpmScriptResolver.prototype, "schema", null);
NpmScriptResolver = __decorate([
    Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_4__["Resolver"])('NpmScript')
], NpmScriptResolver);



/***/ }),

/***/ 2604:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return DocsResolver; });
/* harmony import */ var _angular_console_schema__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(209);
/* harmony import */ var _api_docs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(615);
/* harmony import */ var _nestjs_graphql__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(173);
/* harmony import */ var _nestjs_graphql__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_2__);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (undefined && undefined.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a, _b;



let DocsResolver = class DocsResolver {
    workspaceDocs(_, context) {
        const deps = {
            ...context.packageJson.dependencies,
            ...context.packageJson.devDependencies
        };
        return _api_docs__WEBPACK_IMPORTED_MODULE_1__[/* docs */ "a"].workspaceDocs(deps).toPromise();
    }
    schematicDocs(_, collectionName, name) {
        return _api_docs__WEBPACK_IMPORTED_MODULE_1__[/* docs */ "a"].schematicDocs(collectionName, null, name).toPromise();
    }
};
__decorate([
    Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_2__["ResolveProperty"])(),
    __param(0, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_2__["Parent"])()), __param(1, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_2__["Context"])()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_a = typeof _angular_console_schema__WEBPACK_IMPORTED_MODULE_0__["Workspace"] !== "undefined" && _angular_console_schema__WEBPACK_IMPORTED_MODULE_0__["Workspace"]) === "function" ? _a : Object, Object]),
    __metadata("design:returntype", void 0)
], DocsResolver.prototype, "workspaceDocs", null);
__decorate([
    Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_2__["ResolveProperty"])(),
    __param(0, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_2__["Parent"])()),
    __param(1, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_2__["Args"])('collectionName')),
    __param(2, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_2__["Args"])('collectionName')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_b = typeof _angular_console_schema__WEBPACK_IMPORTED_MODULE_0__["Workspace"] !== "undefined" && _angular_console_schema__WEBPACK_IMPORTED_MODULE_0__["Workspace"]) === "function" ? _b : Object, String, String]),
    __metadata("design:returntype", void 0)
], DocsResolver.prototype, "schematicDocs", null);
DocsResolver = __decorate([
    Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_2__["Resolver"])('Docs')
], DocsResolver);



/***/ }),

/***/ 2605:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return WorkspaceResolver; });
/* harmony import */ var _nestjs_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(125);
/* harmony import */ var _nestjs_common__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_nestjs_common__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _angular_console_schema__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(209);
/* harmony import */ var _api_read_settings__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(192);
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(156);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _api_read_schematic_collections__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2606);
/* harmony import */ var _nestjs_graphql__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(173);
/* harmony import */ var _nestjs_graphql__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_6__);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (undefined && undefined.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a, _b, _c, _d;







let WorkspaceResolver = class WorkspaceResolver {
    constructor(store) {
        this.store = store;
    }
    schematicCollections(name, context) {
        const settings = Object(_api_read_settings__WEBPACK_IMPORTED_MODULE_2__[/* readSettings */ "a"])(this.store);
        if (!Object(_utils_utils__WEBPACK_IMPORTED_MODULE_3__[/* directoryExists */ "b"])(path__WEBPACK_IMPORTED_MODULE_4__["join"](context.path, 'node_modules'))) {
            throw new Error(`node_modules is not found`);
        }
        return Object(_utils_utils__WEBPACK_IMPORTED_MODULE_3__[/* filterByName */ "f"])(Object(_api_read_schematic_collections__WEBPACK_IMPORTED_MODULE_5__[/* readAllSchematicCollections */ "a"])(context.path, settings.workspaceSchematicsDirectory, settings.workspaceSchematicsNpmScript), { name });
    }
    npmScripts(workspace, name) {
        return Object(_utils_utils__WEBPACK_IMPORTED_MODULE_3__[/* filterByName */ "f"])(workspace.npmScripts, { name });
    }
    projects(workspace, name) {
        return Object(_utils_utils__WEBPACK_IMPORTED_MODULE_3__[/* filterByName */ "f"])(workspace.projects, { name });
    }
    completions(workspace) {
        return workspace;
    }
    docs(workspace) {
        return workspace;
    }
};
__decorate([
    Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_6__["ResolveProperty"])(),
    __param(0, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_6__["Args"])('name')),
    __param(1, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_6__["Context"])()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Array)
], WorkspaceResolver.prototype, "schematicCollections", null);
__decorate([
    Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_6__["ResolveProperty"])(),
    __param(0, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_6__["Parent"])()),
    __param(1, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_6__["Args"])('name')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_a = typeof _angular_console_schema__WEBPACK_IMPORTED_MODULE_1__["Workspace"] !== "undefined" && _angular_console_schema__WEBPACK_IMPORTED_MODULE_1__["Workspace"]) === "function" ? _a : Object, String]),
    __metadata("design:returntype", Array)
], WorkspaceResolver.prototype, "npmScripts", null);
__decorate([
    Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_6__["ResolveProperty"])(),
    __param(0, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_6__["Parent"])()),
    __param(1, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_6__["Args"])('name')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_b = typeof _angular_console_schema__WEBPACK_IMPORTED_MODULE_1__["Workspace"] !== "undefined" && _angular_console_schema__WEBPACK_IMPORTED_MODULE_1__["Workspace"]) === "function" ? _b : Object, String]),
    __metadata("design:returntype", Array)
], WorkspaceResolver.prototype, "projects", null);
__decorate([
    Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_6__["ResolveProperty"])(),
    __param(0, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_6__["Parent"])()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_c = typeof _angular_console_schema__WEBPACK_IMPORTED_MODULE_1__["Workspace"] !== "undefined" && _angular_console_schema__WEBPACK_IMPORTED_MODULE_1__["Workspace"]) === "function" ? _c : Object]),
    __metadata("design:returntype", void 0)
], WorkspaceResolver.prototype, "completions", null);
__decorate([
    Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_6__["ResolveProperty"])(),
    __param(0, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_6__["Parent"])()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_d = typeof _angular_console_schema__WEBPACK_IMPORTED_MODULE_1__["Workspace"] !== "undefined" && _angular_console_schema__WEBPACK_IMPORTED_MODULE_1__["Workspace"]) === "function" ? _d : Object]),
    __metadata("design:returntype", void 0)
], WorkspaceResolver.prototype, "docs", null);
WorkspaceResolver = __decorate([
    Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_6__["Resolver"])('Workspace'),
    __param(0, Object(_nestjs_common__WEBPACK_IMPORTED_MODULE_0__["Inject"])('store')),
    __metadata("design:paramtypes", [Object])
], WorkspaceResolver);



/***/ }),

/***/ 2606:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return readAllSchematicCollections; });
/* unused harmony export canAdd */
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(156);


function readAllSchematicCollections(basedir, workspaceSchematicsPath, workspaceSchematicsNpmScript) {
    const npmClient = Object(_utils_utils__WEBPACK_IMPORTED_MODULE_1__[/* fileExistsSync */ "d"])(path__WEBPACK_IMPORTED_MODULE_0__["join"](basedir, 'yarn.lock'))
        ? 'yarn'
        : 'npm';
    let collections = readSchematicCollectionsFromNodeModules(basedir);
    if (Object(_utils_utils__WEBPACK_IMPORTED_MODULE_1__[/* directoryExists */ "b"])(path__WEBPACK_IMPORTED_MODULE_0__["join"](basedir, workspaceSchematicsPath))) {
        collections = [
            readWorkspaceSchematicsCollection(basedir, workspaceSchematicsPath, npmClient, workspaceSchematicsNpmScript),
            ...collections
        ];
    }
    return collections.filter(collection => !!collection && collection.schematics.length > 0);
}
function readAngularJsonDefaults(basedir) {
    const defaults = Object(_utils_utils__WEBPACK_IMPORTED_MODULE_1__[/* readJsonFile */ "n"])('angular.json', basedir).json.schematics;
    const collectionDefaults = Object.keys(defaults ? defaults : {}).reduce((collectionDefaultsMap, key) => {
        const [collectionName, schematicName] = key.split(':');
        if (!collectionDefaultsMap[collectionName]) {
            collectionDefaultsMap[collectionName] = {};
        }
        collectionDefaultsMap[collectionName][schematicName] = defaults[key];
        return collectionDefaultsMap;
    }, {});
    return collectionDefaults;
}
function readSchematicCollectionsFromNodeModules(basedir) {
    const nodeModulesDir = path__WEBPACK_IMPORTED_MODULE_0__["join"](basedir, 'node_modules');
    const packages = Object(_utils_utils__WEBPACK_IMPORTED_MODULE_1__[/* listOfUnnestedNpmPackages */ "k"])(nodeModulesDir);
    const schematicCollections = packages.filter(p => {
        try {
            return !!Object(_utils_utils__WEBPACK_IMPORTED_MODULE_1__[/* readJsonFile */ "n"])(path__WEBPACK_IMPORTED_MODULE_0__["join"](p, 'package.json'), nodeModulesDir).json
                .schematics;
        }
        catch (e) {
            if (e.message &&
                (e.message.indexOf('no such file') > -1 ||
                    e.message.indexOf('not a directory') > -1)) {
                return false;
            }
            else {
                throw e;
            }
        }
    });
    const defaults = readAngularJsonDefaults(basedir);
    return schematicCollections.map(c => readCollection(nodeModulesDir, c, defaults));
}
function readWorkspaceSchematicsCollection(basedir, workspaceSchematicsPath, npmClient, workspaceSchematicsNpmScript) {
    const collectionDir = path__WEBPACK_IMPORTED_MODULE_0__["join"](basedir, workspaceSchematicsPath);
    const collectionName = 'Workspace Schematics';
    if (Object(_utils_utils__WEBPACK_IMPORTED_MODULE_1__[/* fileExistsSync */ "d"])(path__WEBPACK_IMPORTED_MODULE_0__["join"](collectionDir, 'collection.json'))) {
        const collection = Object(_utils_utils__WEBPACK_IMPORTED_MODULE_1__[/* readJsonFile */ "n"])('collection.json', collectionDir);
        const defaults = readAngularJsonDefaults(basedir);
        return readCollectionSchematics(collectionName, collection.path, collection.json, defaults);
    }
    else {
        const schematics = Object(_utils_utils__WEBPACK_IMPORTED_MODULE_1__[/* listFiles */ "j"])(collectionDir)
            .filter(f => path__WEBPACK_IMPORTED_MODULE_0__["basename"](f) === 'schema.json')
            .map(f => {
            const schemaJson = Object(_utils_utils__WEBPACK_IMPORTED_MODULE_1__[/* readJsonFile */ "n"])(f, '');
            return {
                name: schemaJson.json.id,
                collection: collectionName,
                schema: Object(_utils_utils__WEBPACK_IMPORTED_MODULE_1__[/* normalizeSchema */ "m"])(schemaJson.json),
                description: '',
                npmClient,
                npmScript: workspaceSchematicsNpmScript
            };
        });
        return { name: collectionName, schematics };
    }
}
function readCollection(basedir, collectionName, defaults) {
    try {
        const packageJson = Object(_utils_utils__WEBPACK_IMPORTED_MODULE_1__[/* readJsonFile */ "n"])(path__WEBPACK_IMPORTED_MODULE_0__["join"](collectionName, 'package.json'), basedir);
        const collection = Object(_utils_utils__WEBPACK_IMPORTED_MODULE_1__[/* readJsonFile */ "n"])(packageJson.json.schematics, path__WEBPACK_IMPORTED_MODULE_0__["dirname"](packageJson.path));
        return readCollectionSchematics(collectionName, collection.path, collection.json, defaults);
    }
    catch (e) {
        return null;
    }
}
function readCollectionSchematics(collectionName, collectionPath, collectionJson, defaults) {
    const schematicCollection = {
        name: collectionName,
        schematics: []
    };
    Object.entries(collectionJson.schematics).forEach(([k, v]) => {
        try {
            if (canAdd(k, v)) {
                const schematicSchema = Object(_utils_utils__WEBPACK_IMPORTED_MODULE_1__[/* readJsonFile */ "n"])(v.schema, path__WEBPACK_IMPORTED_MODULE_0__["dirname"](collectionPath));
                const projectDefaults = defaults && defaults[collectionName] && defaults[collectionName][k];
                schematicCollection.schematics.push({
                    name: k,
                    collection: collectionName,
                    schema: Object(_utils_utils__WEBPACK_IMPORTED_MODULE_1__[/* normalizeSchema */ "m"])(schematicSchema.json, projectDefaults),
                    description: v.description || '',
                    npmClient: null,
                    npmScript: null
                });
            }
        }
        catch (e) {
            console.error(`Invalid package.json for schematic ${collectionName}:${k}`);
        }
    });
    return schematicCollection;
}
function canAdd(name, s) {
    return !s.hidden && !s.private && !s.extends && name !== 'ng-add';
}


/***/ }),

/***/ 2607:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ArchitectResolver; });
/* harmony import */ var _angular_console_schema__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(209);
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(156);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _api_read_projects__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(701);
/* harmony import */ var _nestjs_graphql__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(173);
/* harmony import */ var _nestjs_graphql__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_4__);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (undefined && undefined.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a;





let ArchitectResolver = class ArchitectResolver {
    schema(parent, context) {
        if (!Object(_utils_utils__WEBPACK_IMPORTED_MODULE_1__[/* directoryExists */ "b"])(path__WEBPACK_IMPORTED_MODULE_2__["join"](context.path, 'node_modules'))) {
            throw new Error(`node_modules is not found`);
        }
        return Object(_api_read_projects__WEBPACK_IMPORTED_MODULE_3__[/* readSchema */ "b"])(context.path, parent.builder);
    }
};
__decorate([
    Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_4__["ResolveProperty"])(),
    __param(0, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_4__["Parent"])()), __param(1, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_4__["Context"])()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_a = typeof _angular_console_schema__WEBPACK_IMPORTED_MODULE_0__["Architect"] !== "undefined" && _angular_console_schema__WEBPACK_IMPORTED_MODULE_0__["Architect"]) === "function" ? _a : Object, Object]),
    __metadata("design:returntype", void 0)
], ArchitectResolver.prototype, "schema", null);
ArchitectResolver = __decorate([
    Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_4__["Resolver"])('Architect')
], ArchitectResolver);



/***/ }),

/***/ 2615:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return getPseudoTerminalFactory; });
/* harmony import */ var _angular_console_server__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(618);
/* harmony import */ var os__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(17);
/* harmony import */ var os__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(os__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var vscode__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(0);
/* harmony import */ var vscode__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(vscode__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _get_store_for_context__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1091);




function getPseudoTerminalFactory(context) {
    const store = Object(_get_store_for_context__WEBPACK_IMPORTED_MODULE_3__[/* getStoreForContext */ "a"])(context);
    return config => {
        if (Object(os__WEBPACK_IMPORTED_MODULE_1__["platform"])() === 'win32') {
            const isWsl = Object(_angular_console_server__WEBPACK_IMPORTED_MODULE_0__[/* readSettings */ "c"])(store).isWsl;
            if (isWsl) {
                return wslPseudoTerminalFactory(context, config);
            }
            else {
                return win32PseudoTerminalFactory(context, config);
            }
        }
        return unixPseudoTerminalFactory(context, config);
    };
}
function win32PseudoTerminalFactory(context, { name, program, args, cwd, displayCommand }) {
    const successMessage = 'Process completed #woot';
    const failureMessage = 'Process failed #failwhale';
    const fullCommand = [
        `Try {`,
        `& '${program}' ${args.join(' ')};`,
        `if($?) { echo '\n\r${successMessage}' };`,
        `if(!$?) { echo '\n\r${failureMessage}' };`,
        `} Catch { `,
        `echo '\n\r${failureMessage}'`,
        `}`
    ].join(' ');
    const terminal = vscode__WEBPACK_IMPORTED_MODULE_2__["window"].createTerminal({
        name,
        cwd,
        shellPath: 'C:\\WINDOWS\\System32\\WindowsPowerShell\\v1.0\\powershell.exe',
        shellArgs: `-Sta -NoLogo -NonInteractive -C "& {${fullCommand}}"`
    });
    return renderVsCodeTerminal(context, terminal, displayCommand, successMessage, failureMessage);
}
function wslPseudoTerminalFactory(context, { name, program, args, cwd, displayCommand }) {
    const successMessage = 'Process completed #woot';
    const failureMessage = 'Process failed #failwhale';
    const fullCommand = `${program} ${args.join(' ')} && echo "\n\r${successMessage}"` +
        ` || echo "\n\r${failureMessage}"`;
    const terminal = vscode__WEBPACK_IMPORTED_MODULE_2__["window"].createTerminal({
        name,
        cwd,
        shellPath: 'C:\\Windows\\System32\\wsl.exe',
        shellArgs: ['-e', 'bash', '-l', '-i', '-c', fullCommand]
    });
    return renderVsCodeTerminal(context, terminal, displayCommand, successMessage, failureMessage);
}
function unixPseudoTerminalFactory(context, { name, program, args, cwd, displayCommand }) {
    const successMessage = 'Process completed 🙏';
    const failureMessage = 'Process failed 🐳';
    const fullCommand = `${program} ${args.join(' ')} && echo "\n\r${successMessage}"` +
        ` || echo "\n\r${failureMessage}"`;
    const terminal = vscode__WEBPACK_IMPORTED_MODULE_2__["window"].createTerminal({
        name,
        cwd,
        shellPath: '/bin/bash',
        shellArgs: ['-c', fullCommand]
    });
    return renderVsCodeTerminal(context, terminal, displayCommand, successMessage, failureMessage);
}
function renderVsCodeTerminal(context, terminal, displayCommand, successMessage, failureMessage) {
    context.subscriptions.push(terminal);
    let onDidWriteData;
    let onExit;
    const disposeTerminal = (code) => {
        onDidWriteData = undefined;
        if (onExit) {
            onExit(code);
            onExit = undefined;
        }
        terminal.dispose();
    };
    context.subscriptions.push(terminal.onDidWriteData((data) => {
        if (onDidWriteData) {
            onDidWriteData(data);
        }
        const success = data.includes(successMessage);
        const failed = data.includes(failureMessage);
        if (success || failed) {
            disposeTerminal(success ? 0 : 1);
        }
    }));
    return {
        onDidWriteData: callback => {
            onDidWriteData = callback;
            callback(`${displayCommand}\n\n\r`);
        },
        onExit: callback => {
            onExit = callback;
        },
        kill: () => {
            if (onDidWriteData) {
                onDidWriteData(`\r\n${failureMessage}`);
            }
            disposeTerminal(1);
        },
        setCols: () => {
        }
    };
}


/***/ }),

/***/ 307:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return commands; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return runCommand; });
/* harmony import */ var _utils_architect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(705);
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(156);
/* harmony import */ var _commands__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1418);
/* harmony import */ var _detailed_status_calculator__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1419);




let commandRunIndex = 0;
const commands = new _commands__WEBPACK_IMPORTED_MODULE_2__[/* Commands */ "a"](5, 15);
function runCommand(type, cwd, programName, program, cmds, pseudoTerminalFactory, fileUtils, addToRecent = true) {
    const workspace = type === 'new' ? null : Object(_utils_utils__WEBPACK_IMPORTED_MODULE_1__[/* readJsonFile */ "n"])('./package.json', cwd).json.name;
    const id = `${program} ${cmds.join(' ')} ${commandRunIndex++}`;
    let command = `${programName} ${cmds.join(' ')}`;
    const supportsNVM = fileUtils.isWsl()
        ? fileUtils.wslSupportsNvm()
        : Boolean(process.env.NVM_DIR);
    if (supportsNVM && fileUtils.useNvm()) {
        command = `nvm exec ${command}`;
        cmds = ['exec', program, ...cmds];
        program = 'nvm';
    }
    const factory = () => {
        const commandRunning = pseudoTerminalFactory({
            displayCommand: command,
            name: id,
            program,
            args: Object(_utils_architect__WEBPACK_IMPORTED_MODULE_0__[/* normalizeCommands */ "e"])(cwd, cmds),
            cwd,
            isWsl: fileUtils.isWsl()
        });
        commandRunning.onDidWriteData(data => {
            commands.addOut(id, data);
        });
        commandRunning.onExit(code => {
            commands.setFinalStatus(id, code === 0 ? 'successful' : 'failed');
        });
        return commandRunning;
    };
    const statusCalculator = Object(_detailed_status_calculator__WEBPACK_IMPORTED_MODULE_3__[/* createDetailedStatusCalculator */ "a"])(cwd, cmds);
    commands.addCommand(type, id, workspace, command, factory, statusCalculator, addToRecent);
    commands.startCommand(id);
    return { id };
}


/***/ }),

/***/ 445:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return QueryResolver; });
/* harmony import */ var _nestjs_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(125);
/* harmony import */ var _nestjs_common__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_nestjs_common__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _angular_console_schema__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(209);
/* harmony import */ var _api_read_ngnews__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1412);
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(156);
/* harmony import */ var _api_read_dependencies__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1416);
/* harmony import */ var _api_read_extensions__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1417);
/* harmony import */ var _api_read_projects__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(701);
/* harmony import */ var _api_read_npm_scripts__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(703);
/* harmony import */ var _api_read_editors__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(704);
/* harmony import */ var _api_run_command__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(307);
/* harmony import */ var _nestjs_graphql__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(173);
/* harmony import */ var _nestjs_graphql__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _api_read_settings__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(192);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (undefined && undefined.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a, _b, _c;












let QueryResolver = class QueryResolver {
    constructor(store) {
        this.store = store;
    }
    settings() {
        return Object(_api_read_settings__WEBPACK_IMPORTED_MODULE_11__[/* readSettings */ "a"])(this.store);
    }
    schematicCollections() {
        try {
            return Object(_api_read_ngnews__WEBPACK_IMPORTED_MODULE_2__[/* schematicCollectionsForNgNew */ "a"])();
        }
        catch (e) {
            console.error(e);
            throw new Error(`Error when reading the collection list. Message: "${e.message}"`);
        }
    }
    workspace(p, context) {
        try {
            if (!_utils_utils__WEBPACK_IMPORTED_MODULE_3__[/* files */ "e"][p]) {
                Object(_utils_utils__WEBPACK_IMPORTED_MODULE_3__[/* cacheFiles */ "a"])(p);
            }
            const packageJson = Object(_utils_utils__WEBPACK_IMPORTED_MODULE_3__[/* readJsonFile */ "n"])('./package.json', p).json;
            const angularJson = Object(_utils_utils__WEBPACK_IMPORTED_MODULE_3__[/* readJsonFile */ "n"])('./angular.json', p).json;
            context.path = p;
            context.packageJson = packageJson;
            context.angularJson = angularJson;
            return {
                name: packageJson.name,
                path: p,
                dependencies: Object(_api_read_dependencies__WEBPACK_IMPORTED_MODULE_4__[/* readDependencies */ "a"])(packageJson),
                extensions: Object(_api_read_extensions__WEBPACK_IMPORTED_MODULE_5__[/* readExtensions */ "b"])(packageJson),
                projects: Object(_api_read_projects__WEBPACK_IMPORTED_MODULE_6__[/* readProjects */ "a"])(angularJson.projects, p, this.store),
                npmScripts: Object(_api_read_npm_scripts__WEBPACK_IMPORTED_MODULE_7__[/* readNpmScripts */ "b"])(p, packageJson),
                docs: {},
                schematicCollections: []
            };
        }
        catch (e) {
            console.error(e);
            throw new Error(`Error when reading the workspace data. Message: "${e.message}"`);
        }
    }
    editors() {
        return Object(_api_read_editors__WEBPACK_IMPORTED_MODULE_8__[/* readEditors */ "c"])();
    }
    availableExtensions(name) {
        try {
            return Object(_utils_utils__WEBPACK_IMPORTED_MODULE_3__[/* filterByName */ "f"])(Object(_api_read_extensions__WEBPACK_IMPORTED_MODULE_5__[/* availableExtensions */ "a"])(), { name });
        }
        catch (e) {
            console.error(e);
            throw new Error(`Error when reading the list of extensions. Message: "${e.message}"`);
        }
    }
    isNodejsInstalled() {
        return {
            result: Object(_api_read_settings__WEBPACK_IMPORTED_MODULE_11__[/* readSettings */ "a"])(this.store).installNodeManually || Object(_utils_utils__WEBPACK_IMPORTED_MODULE_3__[/* exists */ "c"])('node')
        };
    }
    commands(id, cols) {
        try {
            const settings = Object(_api_read_settings__WEBPACK_IMPORTED_MODULE_11__[/* readSettings */ "a"])(this.store);
            const includeDetailedStatus = settings.enableDetailedStatus || false;
            if (id) {
                const c = _api_run_command__WEBPACK_IMPORTED_MODULE_9__[/* commands */ "a"].findMatchingCommand(id, _api_run_command__WEBPACK_IMPORTED_MODULE_9__[/* commands */ "a"].history);
                if (!c)
                    return [];
                const r = serializeIndividualCommand(c, cols || 80, includeDetailedStatus);
                c.outChunk = '';
                return [r];
            }
            else {
                return _api_run_command__WEBPACK_IMPORTED_MODULE_9__[/* commands */ "a"].recent.map(serializeCommandInList);
            }
        }
        catch (e) {
            console.error(e);
            throw new Error(`Error when reading commands. Message: "${e.message}"`);
        }
    }
};
__decorate([
    Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_10__["Query"])(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", typeof (_a = typeof _angular_console_schema__WEBPACK_IMPORTED_MODULE_1__["Settings"] !== "undefined" && _angular_console_schema__WEBPACK_IMPORTED_MODULE_1__["Settings"]) === "function" ? _a : Object)
], QueryResolver.prototype, "settings", null);
__decorate([
    Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_10__["Query"])(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Array)
], QueryResolver.prototype, "schematicCollections", null);
__decorate([
    Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_10__["Query"])(),
    __param(0, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_10__["Args"])('path')), __param(1, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_10__["Context"])()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", typeof (_b = typeof _angular_console_schema__WEBPACK_IMPORTED_MODULE_1__["Workspace"] !== "undefined" && _angular_console_schema__WEBPACK_IMPORTED_MODULE_1__["Workspace"]) === "function" ? _b : Object)
], QueryResolver.prototype, "workspace", null);
__decorate([
    Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_10__["Query"])(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Array)
], QueryResolver.prototype, "editors", null);
__decorate([
    Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_10__["Query"])(),
    __param(0, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_10__["Args"])('name')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Array)
], QueryResolver.prototype, "availableExtensions", null);
__decorate([
    Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_10__["Query"])(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", typeof (_c = typeof _angular_console_schema__WEBPACK_IMPORTED_MODULE_1__["IsNodeInstalledResult"] !== "undefined" && _angular_console_schema__WEBPACK_IMPORTED_MODULE_1__["IsNodeInstalledResult"]) === "function" ? _c : Object)
], QueryResolver.prototype, "isNodejsInstalled", null);
__decorate([
    Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_10__["Query"])(),
    __param(0, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_10__["Args"])('id')),
    __param(1, Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_10__["Args"])('cols')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Number]),
    __metadata("design:returntype", Array)
], QueryResolver.prototype, "commands", null);
QueryResolver = __decorate([
    Object(_nestjs_graphql__WEBPACK_IMPORTED_MODULE_10__["Resolver"])(),
    __param(0, Object(_nestjs_common__WEBPACK_IMPORTED_MODULE_0__["Inject"])('store')),
    __metadata("design:paramtypes", [Object])
], QueryResolver);

function serializeIndividualCommand(c, cols, includeDetailedStatus) {
    if (c.commandRunning) {
        c.commandRunning.setCols(cols);
    }
    return {
        id: c.id,
        workspace: c.workspace,
        command: c.command,
        status: c.status,
        out: c.out,
        outChunk: c.outChunk,
        detailedStatus: includeDetailedStatus && c.detailedStatusCalculator.detailedStatus
            ? JSON.stringify(c.detailedStatusCalculator.detailedStatus)
            : null
    };
}
function serializeCommandInList(c) {
    return {
        id: c.id,
        workspace: c.workspace,
        command: c.command,
        status: c.status
    };
}


/***/ }),

/***/ 615:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* unused harmony export Docs */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return docs; });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(232);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(rxjs__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(369);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__);


class EmptyDocsProvider {
    workspaceDocs(_dependencies) {
        return Object(rxjs__WEBPACK_IMPORTED_MODULE_0__["of"])([]);
    }
    schematicDocs(_collectionName, _collectionVersion, _name) {
        return Object(rxjs__WEBPACK_IMPORTED_MODULE_0__["of"])([]);
    }
    openDoc(_id) {
        return Object(rxjs__WEBPACK_IMPORTED_MODULE_0__["of"])(false);
    }
}
class Docs {
    constructor() {
        this.providers = [new EmptyDocsProvider()];
    }
    addProvider(docProvider) {
        this.providers.push(docProvider);
    }
    workspaceDocs(dependencies) {
        return this.collectInfoFromProviders(p => p.workspaceDocs(dependencies));
    }
    schematicDocs(collectionName, collectionVersion, name) {
        return this.collectInfoFromProviders(p => p.schematicDocs(collectionName, collectionVersion, name));
    }
    openDoc(id) {
        return Object(rxjs__WEBPACK_IMPORTED_MODULE_0__["of"])(...this.providers).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["concatMap"])(p => p.openDoc(id).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["catchError"])(e => {
            console.log(`error`, e.message);
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_0__["of"])(false);
        }))), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["takeWhile"])(r => !r), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["reduce"])((_, c) => c, false));
    }
    collectInfoFromProviders(callback) {
        return Object(rxjs__WEBPACK_IMPORTED_MODULE_0__["of"])(...this.providers).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["concatMap"])(d => {
            try {
                return callback(d).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["catchError"])(e => {
                    console.error(`error`, e.message);
                    return [];
                }));
            }
            catch (e) {
                console.error(`error`, e.message);
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_0__["of"])([]);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["reduce"])((m, c) => [...m, ...c], []));
    }
}
const docs = new Docs();


/***/ }),

/***/ 616:
/***/ (function(module, exports) {



/***/ }),

/***/ 617:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return Telemetry; });
/* harmony import */ var universal_analytics__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2608);
/* harmony import */ var universal_analytics__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(universal_analytics__WEBPACK_IMPORTED_MODULE_0__);

const uuidv4 = __webpack_require__(184);
class Telemetry {
    constructor(store) {
        this.store = store;
        this.visitor = new universal_analytics__WEBPACK_IMPORTED_MODULE_0__["Visitor"]('UA-88380372-8', this.getUuiId(), {
            https: true
        });
    }
    dataCollectionEvent(value) {
        try {
            this.visitor
                .event('DataCollection', 'DataCollectionResponse', value.toString())
                .send();
        }
        catch (e) {
            console.error('dataCollectionEvent', e);
        }
    }
    reportEvent(category, action, label, value) {
        try {
            if (value) {
                this.visitor.event(category, action, label, value, {}).send();
            }
            else {
                this.visitor.event(category, action, label).send();
            }
        }
        catch (e) {
            console.error('reportEvent', e);
        }
    }
    reportLifecycleEvent(action) {
        try {
            if (this.canCollectData()) {
                this.visitor.event('Lifecycle', action).send();
            }
        }
        catch (e) {
            console.error('reportLifecycleEvent', e);
        }
    }
    reportException(description) {
        try {
            if (this.canCollectData()) {
                console.error(description);
                this.visitor.exception(description).send();
            }
        }
        catch (e) {
            console.error('reportException', e);
        }
    }
    reportPageView(path) {
        try {
            if (this.canCollectData()) {
                this.visitor.pageview(path, 'Angular Console', '6.0.0').send();
            }
        }
        catch (e) {
            console.error('reportPageView', e);
        }
    }
    getUuiId() {
        if (this.store.get('uuid')) {
            return this.store.get('uuid');
        }
        const uuid = uuidv4();
        this.store.set('uuid', uuid);
        return uuid;
    }
    canCollectData() {
        const settings = this.store.get('settings');
        return settings && settings.canCollectData;
    }
}


/***/ }),

/***/ 618:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _lib_resolvers_query_resolver__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(445);
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _lib_resolvers_query_resolver__WEBPACK_IMPORTED_MODULE_0__["a"]; });

/* harmony import */ var _lib_api_read_settings__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(192);
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "c", function() { return _lib_api_read_settings__WEBPACK_IMPORTED_MODULE_1__["a"]; });

/* harmony import */ var _lib_server_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1088);
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "b", function() { return _lib_server_module__WEBPACK_IMPORTED_MODULE_2__["a"]; });

/* harmony import */ var _lib_utils_telemetry__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(617);
/* harmony import */ var _lib_api_run_command__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(307);
/* harmony import */ var _lib_types__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(616);
/* harmony import */ var _lib_types__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_lib_types__WEBPACK_IMPORTED_MODULE_5__);









/***/ }),

/***/ 700:
/***/ (function(module, exports) {



/***/ }),

/***/ 701:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return readProjects; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return readSchema; });
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(156);
/* harmony import */ var _read_recent_actions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(702);



function readProjects(json, baseDir, store) {
    return Object.entries(json)
        .map(([key, value]) => {
        return {
            name: key,
            root: value.root,
            projectType: value.projectType,
            architect: readArchitect(key, value.architect),
            recentActions: Object(_read_recent_actions__WEBPACK_IMPORTED_MODULE_2__[/* readRecentActions */ "a"])(store, path__WEBPACK_IMPORTED_MODULE_0__["join"](baseDir, value.root, key))
        };
    })
        .sort(compareProjects);
}
function compareProjects(a, b) {
    return a.root.localeCompare(b.root);
}
function readArchitect(project, architect) {
    if (!architect)
        return [];
    return Object.entries(architect).map(([key, value]) => {
        const options = {
            defaultValues: serializeDefaultsForConfig(value.options)
        };
        const configurations = value.configurations
            ? Object.keys(value.configurations).map(name => ({
                name,
                defaultValues: readDefaultValues(value.options, value.configurations, name)
            }))
            : [];
        return {
            schema: [],
            options,
            configurations,
            name: key,
            project,
            description: value.description || '',
            builder: value.builder
        };
    });
}
function readDefaultValues(options, configurations, name) {
    return serializeDefaultsForConfig({ ...options, ...configurations[name] });
}
function serializeDefaultsForConfig(config) {
    if (!config)
        return [];
    return Object.keys(config).reduce((m, k) => [...m, { name: k, defaultValue: Object(_utils_utils__WEBPACK_IMPORTED_MODULE_1__[/* getPrimitiveValue */ "h"])(config[k]) }], []);
}
function readSchema(basedir, builder) {
    const [npmPackage, builderName] = builder.split(':');
    return readBuildersFile(basedir, npmPackage)[builderName].schema;
}
function readBuildersFile(basedir, npmPackage) {
    const packageJson = Object(_utils_utils__WEBPACK_IMPORTED_MODULE_1__[/* readJsonFile */ "n"])(path__WEBPACK_IMPORTED_MODULE_0__["join"](npmPackage, 'package.json'), path__WEBPACK_IMPORTED_MODULE_0__["join"](basedir, 'node_modules'));
    const b = packageJson.json.builders;
    const buildersPath = b.startsWith('.') ? b : `./${b}`;
    const buildersJson = Object(_utils_utils__WEBPACK_IMPORTED_MODULE_1__[/* readJsonFile */ "n"])(buildersPath, path__WEBPACK_IMPORTED_MODULE_0__["dirname"](packageJson.path));
    const builders = {};
    Object.entries(buildersJson.json.builders).forEach(([k, v]) => {
        const builderSchema = Object(_utils_utils__WEBPACK_IMPORTED_MODULE_1__[/* readJsonFile */ "n"])(v.schema, path__WEBPACK_IMPORTED_MODULE_0__["dirname"](buildersJson.path));
        builders[k] = {
            name: k,
            schema: Object(_utils_utils__WEBPACK_IMPORTED_MODULE_1__[/* normalizeSchema */ "m"])(builderSchema.json),
            description: v.description || ''
        };
    });
    return builders;
}


/***/ }),

/***/ 702:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return readRecentActions; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return storeTriggeredAction; });
function getRecentActionsKey(projectPath) {
    return `recentActions:${projectPath}`;
}
function readRecentActions(store, projectPath) {
    const actions = store.get(getRecentActionsKey(projectPath));
    return (actions || []).filter(action => action && !!action.actionName);
}
function storeTriggeredAction(store, projectPath, actionName, schematicName) {
    const MAX_RECENT_ACTIONS = 5;
    const existingActions = readRecentActions(store, projectPath);
    store.set(getRecentActionsKey(projectPath), [
        { actionName, schematicName },
        ...existingActions.filter(action => action.actionName !== actionName ||
            action.schematicName !== schematicName)
    ].slice(0, MAX_RECENT_ACTIONS));
}


/***/ }),

/***/ 703:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return readNpmScripts; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return readNpmScriptSchema; });
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(156);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_1__);


function readNpmScripts(workspacePath, packageJson) {
    const npmClient = Object(_utils_utils__WEBPACK_IMPORTED_MODULE_0__[/* fileExistsSync */ "d"])(path__WEBPACK_IMPORTED_MODULE_1__["join"](workspacePath, 'yarn.lock'))
        ? 'yarn'
        : 'npm';
    return Object.keys(packageJson.scripts || {}).map(name => {
        return { name, npmClient, schema: [] };
    });
}
function readNpmScriptSchema(_workspacePath, _scriptName) {
    return [
        {
            name: 'arguments',
            type: 'arguments',
            description: 'script arguments',
            required: false,
            positional: false
        }
    ];
}


/***/ }),

/***/ 704:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return readEditors; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return openInEditor; });
/* harmony import */ var child_process__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(92);
/* harmony import */ var child_process__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(child_process__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(fs__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var os__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(17);
/* harmony import */ var os__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(os__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(156);




function readEditors() {
    const editors = [];
    if (os__WEBPACK_IMPORTED_MODULE_2__["platform"]() === 'darwin') {
        editors.push({ name: 'Finder', icon: 'finder' });
        editors.push({ name: 'Terminal', icon: 'terminal' });
    }
    if (hasNautilus()) {
        editors.push({ name: 'Files', icon: 'nautilus' });
    }
    if (hasExplorer()) {
        editors.push({ name: 'Explorer', icon: 'explorer' });
    }
    if (hasWebStorm()) {
        editors.push({ name: 'WebStorm', icon: 'webstorm' });
    }
    if (hasIntellij()) {
        editors.push({ name: 'IntelliJ IDEA', icon: 'intellij' });
    }
    if (hasVsCode()) {
        editors.push({ name: 'VS Code', icon: 'vscode' });
    }
    if (hasVsCode({ insiders: true })) {
        editors.push({ name: 'VS Code - Insiders', icon: 'vscode-insiders' });
    }
    return editors;
}
function openInEditor(editor, path) {
    switch (editor) {
        case 'Finder':
            return openInFinder(path);
        case 'Terminal':
            return openInOsXTerminal(path);
        case 'Files':
            return openInNautilus(path);
        case 'Explorer':
            return openInExplorer(path);
        case 'VS Code':
            return openInVsCode(path);
        case 'VS Code - Insiders':
            return openInVsCode(path, { insiders: true });
        case 'WebStorm':
            return openInWebStorm(path);
        case 'IntelliJ IDEA':
            return openInIntelliJ(path);
        default:
            throw new Error(`Unknown editor: ${editor}`);
    }
}
function hasNautilus() {
    return Object(_utils_utils__WEBPACK_IMPORTED_MODULE_3__[/* exists */ "c"])('nautilus');
}
function hasExplorer() {
    return os__WEBPACK_IMPORTED_MODULE_2__["platform"]() === 'win32';
}
function hasVsCode(config = { insiders: false }) {
    const { insiders } = config;
    if (os__WEBPACK_IMPORTED_MODULE_2__["platform"]() === 'darwin') {
        try {
            const apps = fs__WEBPACK_IMPORTED_MODULE_1__["readdirSync"]('/Applications');
            const appName = insiders
                ? 'Visual Studio Code - Insiders.app'
                : 'Visual Studio Code.app';
            return apps.indexOf(appName) > -1;
        }
        catch (e) {
            return false;
        }
    }
    else if (os__WEBPACK_IMPORTED_MODULE_2__["platform"]() === 'linux') {
        return Object(_utils_utils__WEBPACK_IMPORTED_MODULE_3__[/* exists */ "c"])(insiders ? 'code-insiders' : 'code');
    }
    else if (os__WEBPACK_IMPORTED_MODULE_2__["platform"]() === 'win32') {
        try {
            return (Object(child_process__WEBPACK_IMPORTED_MODULE_0__["execSync"])(`${insiders ? 'code-insiders' : 'code'} --version`)
                .toString()
                .indexOf('is not recognized') === -1);
        }
        catch (e) {
            return false;
        }
    }
    else {
        return false;
    }
}
function hasWebStorm() {
    if (os__WEBPACK_IMPORTED_MODULE_2__["platform"]() === 'darwin') {
        try {
            const apps = fs__WEBPACK_IMPORTED_MODULE_1__["readdirSync"]('/Applications');
            return apps.indexOf('WebStorm.app') > -1;
        }
        catch (e) {
            return false;
        }
    }
    else if (os__WEBPACK_IMPORTED_MODULE_2__["platform"]() === 'linux') {
        return Object(_utils_utils__WEBPACK_IMPORTED_MODULE_3__[/* exists */ "c"])('wstorm') || Object(_utils_utils__WEBPACK_IMPORTED_MODULE_3__[/* exists */ "c"])('webstorm.sh');
    }
    else if (os__WEBPACK_IMPORTED_MODULE_2__["platform"]() === 'win32') {
        return Object(_utils_utils__WEBPACK_IMPORTED_MODULE_3__[/* hasExecutable */ "i"])('webstorm', process.cwd());
    }
    else {
        return false;
    }
}
function hasIntellij() {
    if (os__WEBPACK_IMPORTED_MODULE_2__["platform"]() === 'darwin') {
        try {
            const apps = fs__WEBPACK_IMPORTED_MODULE_1__["readdirSync"]('/Applications');
            return apps.indexOf('IntelliJ IDEA.app') > -1;
        }
        catch (e) {
            return false;
        }
    }
    else if (os__WEBPACK_IMPORTED_MODULE_2__["platform"]() === 'linux') {
        return Object(_utils_utils__WEBPACK_IMPORTED_MODULE_3__[/* exists */ "c"])('idea');
    }
    else if (os__WEBPACK_IMPORTED_MODULE_2__["platform"]() === 'win32') {
        return Object(_utils_utils__WEBPACK_IMPORTED_MODULE_3__[/* hasExecutable */ "i"])('idea', process.cwd());
    }
    else {
        return false;
    }
}
function openInFinder(path) {
    if (os__WEBPACK_IMPORTED_MODULE_2__["platform"]() === 'darwin') {
        Object(child_process__WEBPACK_IMPORTED_MODULE_0__["spawn"])('open', [path], { detached: true });
    }
}
function openInNautilus(path) {
    Object(child_process__WEBPACK_IMPORTED_MODULE_0__["exec"])(`nautilus ${path}`);
}
function openInExplorer(path) {
    if (os__WEBPACK_IMPORTED_MODULE_2__["platform"]() === 'win32') {
        Object(child_process__WEBPACK_IMPORTED_MODULE_0__["exec"])(`start "" "${path}"`);
    }
}
function openInVsCode(path, config = { insiders: false }) {
    const { insiders } = config;
    if (os__WEBPACK_IMPORTED_MODULE_2__["platform"]() === 'darwin') {
        Object(child_process__WEBPACK_IMPORTED_MODULE_0__["spawn"])('open', [
            '-a',
            insiders ? 'Visual Studio Code - Insiders' : 'Visual Studio Code',
            path
        ], { detached: true });
    }
    else if (os__WEBPACK_IMPORTED_MODULE_2__["platform"]() === 'linux') {
        Object(child_process__WEBPACK_IMPORTED_MODULE_0__["exec"])(`${insiders ? 'code-insiders' : 'code'} ${path}`);
    }
    else if (os__WEBPACK_IMPORTED_MODULE_2__["platform"]() === 'win32') {
        Object(child_process__WEBPACK_IMPORTED_MODULE_0__["exec"])(`${insiders ? 'code-insiders' : 'code'} "${toWindows(path)}"`);
    }
}
function openInOsXTerminal(path) {
    Object(child_process__WEBPACK_IMPORTED_MODULE_0__["spawn"])('open', ['-a', 'Terminal', path], { detached: true });
}
function openInWebStorm(path) {
    if (os__WEBPACK_IMPORTED_MODULE_2__["platform"]() === 'darwin') {
        Object(child_process__WEBPACK_IMPORTED_MODULE_0__["spawn"])('open', ['-a', 'WebStorm', path], { detached: true });
    }
    else if (os__WEBPACK_IMPORTED_MODULE_2__["platform"]() === 'linux') {
        if (Object(_utils_utils__WEBPACK_IMPORTED_MODULE_3__[/* exists */ "c"])('wstorm')) {
            Object(child_process__WEBPACK_IMPORTED_MODULE_0__["exec"])(`wstorm ${path}`);
        }
        else {
            Object(child_process__WEBPACK_IMPORTED_MODULE_0__["exec"])(`webstorm.sh ${path}`);
        }
    }
    else if (os__WEBPACK_IMPORTED_MODULE_2__["platform"]() === 'win32') {
        Object(child_process__WEBPACK_IMPORTED_MODULE_0__["spawn"])(Object(_utils_utils__WEBPACK_IMPORTED_MODULE_3__[/* findExecutable */ "g"])('webstorm', process.cwd()), [toWindows(path)], {
            detached: true
        });
    }
}
function openInIntelliJ(path) {
    if (os__WEBPACK_IMPORTED_MODULE_2__["platform"]() === 'darwin') {
        Object(child_process__WEBPACK_IMPORTED_MODULE_0__["spawn"])('open', ['-a', 'IntelliJ IDEA', path], { detached: true });
    }
    else if (os__WEBPACK_IMPORTED_MODULE_2__["platform"]() === 'linux') {
        Object(child_process__WEBPACK_IMPORTED_MODULE_0__["exec"])(`idea ${path}`);
    }
    else if (os__WEBPACK_IMPORTED_MODULE_2__["platform"]() === 'win32') {
        Object(child_process__WEBPACK_IMPORTED_MODULE_0__["spawn"])(Object(_utils_utils__WEBPACK_IMPORTED_MODULE_3__[/* findExecutable */ "g"])('idea', process.cwd()), [toWindows(path)], {
            detached: true
        });
    }
}
function toWindows(path) {
    return path
        .split('/')
        .filter(p => !!p)
        .join('\\');
}


/***/ }),

/***/ 705:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return SUPPORTED_KARMA_TEST_BUILDERS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return SUPPORTED_SERVE_BUILDERS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return SUPPORTED_BUILD_BUILDERS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "e", function() { return normalizeCommands; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return getProjectArchitect; });
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(fs__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(156);



const SUPPORTED_KARMA_TEST_BUILDERS = [
    '@angular-devkit/build-angular:karma'
];
const SUPPORTED_SERVE_BUILDERS = [
    '@angular-devkit/build-angular:dev-server',
    '@nrwl/builders:web-dev-server'
];
const SUPPORTED_BUILD_BUILDERS = [
    '@angular-devkit/build-angular:browser',
    '@nrwl/builders:web-build'
];
function normalizeCommands(cwd, cmds) {
    const operationName = cmds[0];
    const project = cmds[1];
    const { json: angularJson } = Object(_utils__WEBPACK_IMPORTED_MODULE_2__[/* readJsonFile */ "n"])('./angular.json', cwd);
    const builder = getProjectArchitect(project, operationName, angularJson)
        .builder;
    let normalized = cmds;
    if (SUPPORTED_KARMA_TEST_BUILDERS.includes(builder)) {
        const projectRoot = angularJson.projects[cmds[1]].root;
        const karmaConfigPath = Object(path__WEBPACK_IMPORTED_MODULE_0__["join"])(cwd, projectRoot, 'karma.conf.js');
        const isUsingKarma = Object(fs__WEBPACK_IMPORTED_MODULE_1__["existsSync"])(karmaConfigPath);
        if (isUsingKarma) {
            normalized = cmds.concat(['--reporters', 'progress']);
        }
    }
    return normalized;
}
function getProjectArchitect(project, operation, angularJson) {
    try {
        return angularJson.projects[project].architect[operation];
    }
    catch (err) {
        return {};
    }
}


/***/ })

};;