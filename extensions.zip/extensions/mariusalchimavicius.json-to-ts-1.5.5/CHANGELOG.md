# Change Log

## 0.0.1
- Initial release

## 0.0.2
- UPDATE: upgrade json-to-ts (key-name validation)

## 0.0.3
- UPDATE: more info in README

## 0.0.4
- FIX: readme icons

## 0.1.0
- FIX: replace selection with types
- FEATURE: json like structure support (optional quotes on keys)

## 0.1.1
- FIX: statistics

## 1.0.0
- Added "Array of Objects" support

## 1.1.0
- array merging

## 1.1.1
- optional types fix

## 1.1.2
- update readme

## 1.2.0
- array merging edge cases fixed

## 1.3.0
- normalizing inavalid interface names (names tart with symbols, numbers, etc.)

## 1.3.1
- normalizing inavalid interface names should be pascal cased

## 1.3.2
- mistakes were made

## 1.4.2
- union types

## 1.4.3
- invalid key optional type fix

## 1.4.4
- underscore naming fixed unquoted

## 1.5.0
- nullable types should be merged

## 1.5.2
- update readme
## 1.5.4
- remove ssl 
