<h1 align="center">Sponsors &amp; Backers</h1>

To my incredible backers &mdash; thank you so much for your contributions. I am truly humbled by your generosity and support. Please know that your support plays an important role in helping me realize GitLens' potential in making developer's lives easier.

If you'd like to join in supporting GitLens, please consider:

- [Become a backer or sponsor on Patreon](https://www.patreon.com/eamodio)
- [PayPal donations](https://www.paypal.me/eamodio)
- [Cash App donations](https://www.paypal.me/eamodio)

<h2 align="center">Gold Sponsors ($100+)</h2>

<p align="center" style="margin: 0 10%">
  <a title="Try CodeStream" href="https://codestream.com/?utm_source=vscmarket&utm_medium=banner&utm_campaign=gitlens"><img src="https://alt-images.codestream.com/codestream_logo_gitlens_vscmarket.png" alt="CodeStream Logo"/></a>
</p>

<p align="center" style="margin: 0 10%">
  <a title="Visit Crésus" href="https://cresus.ch"><img src="https://raw.githubusercontent.com/eamodio/vscode-gitlens/master/images/docs/sponsors/cresus.png" alt="Crésus Logo"/></a>
</p>

<h2 align="center">Silver Sponsors ($50+)</h2>

None currently &mdash; could be you or your company here!

<h2 align="center">Bronze Sponsors ($25+)</h2>

None currently &mdash; could be you or your company here!

<h2 align="center">Generous Backers ($10+)</h2>

- Borek Bernard
- Jack
- Ken Howard
- Michael Duffy (former Silver Sponsor)
- Michael Scott-Nelson
- MrG0lden
- Sergey Cheperis
- Xananax

<h2 align="center">Backers</h2>

- Andreas Fertsch-Röver
- Bill
- Brandon Burroughs
- Brent Schmidt
- Diego La Manno
- Eugen Grue
- Georg Hartmann
- Guido Kessels
- J Burnett
- JehongAhn
- Jon G
- Jordan Oroshiba
- Karl
- Michael Melanson
- Niklas Lochschmidt
- Pavel Khlopin
- Pelle Wessman
- Raphael Schweikert
- sombriks
- Stephen Kelley
- Steven Hepting
- Sunny Gupta
- Vance Dubberly
- Øyvind de Freitas Sørensen
